package com.reed.encryptednotebook.security

interface CipherMethod {
    val id: String
    val displayNameUk: String
    val displayNameEn: String
    fun encrypt(plainText: String, key: ByteArray): Ciphertext
    fun decrypt(ciphertext: Ciphertext, key: ByteArray): String
}

data class Ciphertext(
    val payload: String,
    val nonce: String? = null
)
