package com.reed.encryptednotebook.security

data class CryptoSession(
    val aesKey: ByteArray,
    val caesarKey: ByteArray
) {
    fun keyFor(mode: String): ByteArray = if (mode == "CAESAR") caesarKey else aesKey

    fun wipe() {
        aesKey.fill(0)
        caesarKey.fill(0)
    }
}
