package com.reed.encryptednotebook

import android.app.Application
import androidx.annotation.Keep
import com.reed.encryptednotebook.data.AppDatabase
import com.reed.encryptednotebook.data.NoteRepository
import com.reed.encryptednotebook.security.SecurityRepository

@Keep
class NotebookApplication : Application() {
    lateinit var security: SecurityRepository
        private set
    lateinit var notes: NoteRepository
        private set

    override fun onCreate() {
        super.onCreate()
        security = SecurityRepository(this)
        notes = NoteRepository(AppDatabase.get(this))
    }
}
