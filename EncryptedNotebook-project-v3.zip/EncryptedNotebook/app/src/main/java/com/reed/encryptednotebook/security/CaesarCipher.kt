package com.reed.encryptednotebook.security

/** Educational/low-security mode. It is intentionally not cryptographically secure. */
class CaesarCipher : CipherMethod {
    override val id = "CAESAR"
    override val displayNameUk = "Простий зсув (Цезар)"
    override val displayNameEn = "Simple shift (Caesar)"

    override fun encrypt(plainText: String, key: ByteArray): Ciphertext =
        Ciphertext(shift(plainText, key.firstOrNull()?.toInt() ?: 0, true), null)

    override fun decrypt(ciphertext: Ciphertext, key: ByteArray): String =
        shift(ciphertext.payload, key.firstOrNull()?.toInt() ?: 0, false)

    private fun shift(text: String, rawShift: Int, forward: Boolean): String {
        val shift = ((rawShift % 31) + 31) % 31
        val actual = if (forward) shift else -shift
        return text.map { ch ->
            when {
                ch in 'A'..'Z' -> ((ch.code - 'A'.code + actual).floorMod(26) + 'A'.code).toChar()
                ch in 'a'..'z' -> ((ch.code - 'a'.code + actual).floorMod(26) + 'a'.code).toChar()
                ch in 'А'..'Я' -> ((ch.code - 'А'.code + actual).floorMod(32) + 'А'.code).toChar()
                ch in 'а'..'я' -> ((ch.code - 'а'.code + actual).floorMod(32) + 'а'.code).toChar()
                else -> ch
            }
        }.joinToString("")
    }

    private fun Int.floorMod(mod: Int): Int = ((this % mod) + mod) % mod
}
