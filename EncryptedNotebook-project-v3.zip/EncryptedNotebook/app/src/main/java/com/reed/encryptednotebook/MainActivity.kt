package com.reed.encryptednotebook

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.ViewList
import androidx.compose.material.icons.filled.Undo
import androidx.compose.material.icons.filled.Redo
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import com.reed.encryptednotebook.data.DecryptedNote
import com.reed.encryptednotebook.data.NoteEntity
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import androidx.compose.runtime.rememberCoroutineScope
import java.security.SecureRandom

class MainActivity : ComponentActivity() {
    private lateinit var viewModel: MainViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        viewModel = ViewModelProvider(this)[MainViewModel::class.java]
        setContent { EncryptedNotebookApp(viewModel) }
    }

    override fun onStop() {
        if (::viewModel.isInitialized) viewModel.onAppBackgrounded()
        super.onStop()
    }

    override fun onStart() {
        super.onStart()
        if (::viewModel.isInitialized) viewModel.onAppForegrounded()
    }

    fun biometricAvailable(): Boolean =
        BiometricManager.from(this).canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_WEAK) == BiometricManager.BIOMETRIC_SUCCESS

    fun launchBiometric(onSuccess: () -> Unit) {
        if (!biometricAvailable()) return
        val prompt = BiometricPrompt(
            this,
            mainExecutor,
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    onSuccess()
                }
            }
        )
        prompt.authenticate(
            BiometricPrompt.PromptInfo.Builder()
                .setTitle("Encrypted Notebook")
                .setSubtitle("Підтвердьте особу, щоб увійти")
                .setNegativeButtonText("Скасувати")
                .build()
        )
    }
}

@Composable
fun EncryptedNotebookApp(vm: MainViewModel) {
    val state by vm.state.collectAsState()
    val context = LocalContext.current
    var lastInteraction by remember { mutableStateOf(System.currentTimeMillis()) }
    fun touch() { lastInteraction = System.currentTimeMillis() }

    LaunchedEffect(state.unlocked, state.autoLockMinutes, state.screen) {
        while (state.unlocked && state.screen != Screen.BACKGROUND) {
            delay(5_000)
            if (System.currentTimeMillis() - lastInteraction >= state.autoLockMinutes * 60_000L) {
                vm.lock()
                break
            }
        }
    }

    val darkTheme = isSystemInDarkTheme()
    MaterialTheme(colorScheme = if (darkTheme) darkColorScheme() else lightColorScheme()) {
        when (state.screen) {
            Screen.ONBOARDING -> OnboardingScreen(state.language) { vm.setLanguage(it); vm.beginSetup() }
            Screen.SETUP_PIN -> SetupPinScreen(vm, state)
            Screen.SETUP_KEY -> SetupKeyScreen(vm, state)
            Screen.WARNING -> WarningScreen(state.language == "uk") { vm.navigate(Screen.PIN) }
            Screen.PIN -> PinScreen(vm, state, context as? MainActivity)
            Screen.LOCKED_NOTES -> LockedNotesScreen(vm, state)
            Screen.MASTER_KEY -> MasterKeyScreen(vm, state)
            Screen.NOTES -> NotesScreen(vm, state, { touch() })
            Screen.EDIT_NOTE -> NoteEditorScreen(vm, state, { touch() })
            Screen.SETTINGS -> SettingsScreen(vm, state)
            Screen.HELP -> HelpScreen(state.language) { vm.navigate(if (state.unlocked) Screen.NOTES else Screen.PIN) }
            Screen.EXPORT -> ExportScreen(vm, state) { vm.navigate(Screen.NOTES) }
            Screen.IMPORT -> ImportScreen(vm, state) { vm.navigate(Screen.NOTES) }
            Screen.BACKGROUND -> Box(Modifier.fillMaxSize())
        }
    }
}

@Composable
private fun OnboardingScreen(language: String, onStart: (String) -> Unit) {
    var page by rememberSaveable { mutableIntStateOf(0) }
    var selectedLanguage by rememberSaveable { mutableStateOf(language) }
    val uk = selectedLanguage == "uk"
    val pages = if (uk) listOf(
        "Що це" to "Офлайн-блокнот для логінів, паролів, кодів та приватних нотаток. Інтернет не потрібен.",
        "PIN і ключ" to "PIN відкриває застосунок. Головний ключ відкриває справжній текст нотаток. Це два різні секрети.",
        "Не забудьте" to "Якщо забудете PIN або головний ключ, відновити нотатки неможливо. Це свідомий компроміс на користь безпеки.",
        "Перенесення" to "Нотатки можна експортувати в один зашифрований Base64-рядок і імпортувати на іншому пристрої з тим самим головним ключем."
    ) else listOf(
        "What is it" to "An offline notebook for logins, passwords, codes and private notes. No internet is required.",
        "PIN and key" to "The PIN opens the app. The master key unlocks the real note text. They are two different secrets.",
        "Do not forget" to "If you forget the PIN or master key, the notes cannot be recovered. This is intentional for security.",
        "Transfer" to "Export notes as one encrypted Base64 string and import them on another device with the same master key."
    )
    Scaffold { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(24.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
            Text("🔐", style = MaterialTheme.typography.displayLarge)
            Spacer(Modifier.height(24.dp))
            Text(pages[page].first, style = MaterialTheme.typography.headlineMedium)
            Spacer(Modifier.height(12.dp))
            Text(pages[page].second, style = MaterialTheme.typography.bodyLarge)
            Spacer(Modifier.height(28.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { repeat(pages.size) { i -> Text(if (i == page) "●" else "○") } }
            Spacer(Modifier.height(24.dp))
            Button(onClick = { if (page < pages.lastIndex) page++ else onStart(selectedLanguage) }) { Text(if (page < pages.lastIndex) if (uk) "Далі" else "Next" else if (uk) "Почати" else "Start") }
            Spacer(Modifier.height(10.dp))
            TextButton(onClick = { selectedLanguage = if (selectedLanguage == "uk") "en" else "uk" }) { Text(if (uk) "English" else "Українська") }
        }
    }
}

@Composable
private fun SetupPinScreen(vm: MainViewModel, state: UiState) {
    val uk = state.language == "uk"
    var pin by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    Scaffold { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(24.dp), verticalArrangement = Arrangement.Center) {
            Text(if (uk) "Створіть PIN" else "Create a PIN", style = MaterialTheme.typography.headlineMedium)
            Spacer(Modifier.height(10.dp))
            Text(if (uk) "4–6 цифр. PIN потрібен для входу в застосунок." else "4–6 digits. The PIN is used to enter the app.")
            Spacer(Modifier.height(20.dp))
            OutlinedTextField(pin, { if (it.all(Char::isDigit) && it.length <= 6) pin = it }, label = { Text("PIN") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(confirm, { if (it.all(Char::isDigit) && it.length <= 6) confirm = it }, label = { Text(if (uk) "Підтвердіть PIN" else "Confirm PIN") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(18.dp))
            Button(onClick = { vm.setSetupPin(pin) }, enabled = pin.length in 4..6 && pin == confirm, modifier = Modifier.fillMaxWidth()) { Text(if (uk) "Далі" else "Next") }
        }
    }
}

@Composable
private fun SetupKeyScreen(vm: MainViewModel, state: UiState) {
    val uk = state.language == "uk"
    var key by remember { mutableStateOf("") }
    Scaffold { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(24.dp), verticalArrangement = Arrangement.Center) {
            Text(if (uk) "Створіть головний ключ" else "Create the master key", style = MaterialTheme.typography.headlineMedium)
            Spacer(Modifier.height(10.dp))
            Text(if (uk) "Введіть парольну фразу або числовий ключ (мінімум 8 символів). Для реальних секретів використовуйте довгу унікальну фразу або випадкове число з 16+ цифр. Короткі числа легко перебрати." else "Enter a passphrase or numeric key (at least 8 characters). Use a long unique passphrase or a random 16+ digit number for real secrets. Short numbers are easy to guess.")
            Spacer(Modifier.height(20.dp))
            OutlinedTextField(key, { if (it.length <= 128) key = it }, label = { Text(if (uk) "Парольна фраза або число" else "Passphrase or number") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(18.dp))
            Button(onClick = { vm.finishSetup(key) }, enabled = key.trim().length >= 8, modifier = Modifier.fillMaxWidth()) { Text(if (uk) "Створити блокнот" else "Create notebook") }
        }
    }
}

@Composable
private fun WarningScreen(uk: Boolean, onContinue: () -> Unit) {
    Scaffold { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(24.dp), verticalArrangement = Arrangement.Center) {
            Text("⚠️", style = MaterialTheme.typography.displayMedium)
            Spacer(Modifier.height(16.dp))
            Text(if (uk) "Якщо ви забудете PIN або ключ, відновити нотатки буде неможливо." else "If you forget the PIN or key, the notes cannot be recovered.", style = MaterialTheme.typography.headlineSmall)
            Spacer(Modifier.height(24.dp))
            Button(onClick = onContinue, modifier = Modifier.fillMaxWidth()) { Text(if (uk) "Я розумію" else "I understand") }
        }
    }
}

@Composable
private fun PinScreen(vm: MainViewModel, state: UiState, activity: MainActivity?) {
    var pin by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var remaining by remember { mutableStateOf(0L) }
    val uk = state.language == "uk"
    LaunchedEffect(Unit) {
        while (true) {
            remaining = vm.pinLockRemaining()
            delay(1000)
        }
    }
    val locked = remaining > 0
    Scaffold { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(24.dp), verticalArrangement = Arrangement.Center) {
            Text("🔐", style = MaterialTheme.typography.displayMedium, modifier = Modifier.align(Alignment.CenterHorizontally))
            Spacer(Modifier.height(12.dp))
            Text(if (uk) "Введіть PIN" else "Enter PIN", style = MaterialTheme.typography.headlineMedium)
            Spacer(Modifier.height(8.dp))
            Text(if (uk) "PIN відкриває застосунок. Потім буде потрібен головний ключ." else "The PIN opens the app. Then the master key is required.")
            Spacer(Modifier.height(20.dp))
            OutlinedTextField(pin, { if (it.all(Char::isDigit) && it.length <= 6) pin = it }, label = { Text("PIN") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), enabled = !locked, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(12.dp))
            Button(onClick = {
                when (val result = vm.verifyPin(pin)) {
                    PinResult.Success -> error = null
                    is PinResult.Wrong -> error = if (uk) "Невірний PIN. Залишилось спроб: ${5 - result.failures}" else "Wrong PIN. Attempts left: ${5 - result.failures}"
                    is PinResult.Locked -> error = if (uk) "PIN заблоковано на 10 хвилин." else "PIN locked for 10 minutes."
                }
            }, enabled = pin.length in 4..6 && !locked, modifier = Modifier.fillMaxWidth()) { Text(if (uk) "Увійти" else "Sign in") }
            if (state.biometricEnabled && activity?.biometricAvailable() == true) {
                Spacer(Modifier.height(10.dp))
                OutlinedButton(onClick = { activity.launchBiometric { vm.unlockWithBiometric() } }, enabled = !locked, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.Fingerprint, null); Spacer(Modifier.width(8.dp)); Text(if (uk) "Увійти біометрією" else "Use biometrics")
                }
            }
            if (locked) { Spacer(Modifier.height(12.dp)); Text(if (uk) "Спробуйте через ${remaining / 1000}s" else "Try again in ${remaining / 1000}s") }
            error?.let { Spacer(Modifier.height(10.dp)); Text(it, color = MaterialTheme.colorScheme.error) }
        }
    }
}

@Composable
private fun LockedNotesScreen(vm: MainViewModel, state: UiState) {
    val uk = state.language == "uk"
    val notes by vm.notes.collectAsState()
    Scaffold(topBar = {
        CenterAlignedTopAppBar(
            title = { Text(if (uk) "Нотатки заблоковані" else "Notes locked") },
            actions = { IconButton(onClick = { vm.lock() }) { Icon(Icons.Default.Lock, null) } }
        )
    }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(12.dp)) {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)) {
                Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.HelpOutline, null)
                    Spacer(Modifier.width(8.dp))
                    Text(if (uk) "PIN пройдено. Текст нотаток поки не розшифрований. Введіть головний ключ, щоб прочитати їх." else "PIN accepted. Note text is still encrypted. Enter the master key to read it.")
                }
            }
            Spacer(Modifier.height(10.dp))
            if (notes.isEmpty()) {
                Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                    Text(if (uk) "Нотаток ще немає." else "There are no notes yet.")
                }
            } else {
                LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(notes, key = { it.id }) { note ->
                        Card(shape = RoundedCornerShape(18.dp)) {
                            Column(Modifier.fillMaxWidth().padding(16.dp)) {
                                Text(note.titleCipher, style = MaterialTheme.typography.titleSmall, maxLines = 2)
                                Spacer(Modifier.height(6.dp))
                                Text(note.bodyCipher, maxLines = 3)
                            }
                        }
                    }
                }
            }
            Button(onClick = { vm.navigate(Screen.MASTER_KEY) }, modifier = Modifier.fillMaxWidth()) {
                Text(if (uk) "Ввести головний ключ" else "Enter master key")
            }
        }
    }
}

@Composable
private fun MasterKeyScreen(vm: MainViewModel, state: UiState) {
    var key by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var remaining by remember { mutableStateOf(0L) }
    var checking by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val uk = state.language == "uk"
    LaunchedEffect(Unit) {
        while (true) { remaining = vm.keyLockRemaining(); delay(1000) }
    }
    val locked = remaining > 0
    Scaffold { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(24.dp), verticalArrangement = Arrangement.Center) {
            Text("🗝️", style = MaterialTheme.typography.displayMedium)
            Spacer(Modifier.height(10.dp))
            Text(if (uk) "Головний ключ" else "Master key", style = MaterialTheme.typography.headlineMedium)
            Spacer(Modifier.height(8.dp))
            Text(if (uk) "Введіть ключ, щоб побачити справжній текст нотаток." else "Enter the key to see the real note text.")
            Spacer(Modifier.height(20.dp))
            OutlinedTextField(key, { if (it.length <= 128) key = it }, label = { Text(if (uk) "Парольна фраза або число" else "Passphrase or number") }, enabled = !locked, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(12.dp))
            Button(onClick = {
                checking = true
                scope.launch {
                    when (val result = vm.verifyMasterKey(key)) {
                        KeyResult.Success -> error = null
                        is KeyResult.Wrong -> error = if (uk) "Невірний ключ. Залишилось спроб: ${5 - result.failures}" else "Wrong key. Attempts left: ${5 - result.failures}"
                        is KeyResult.Locked -> error = if (uk) "Ключ заблоковано на 10 хвилин." else "Key locked for 10 minutes."
                    }
                    checking = false
                }
            }, enabled = key.isNotBlank() && !locked && !checking, modifier = Modifier.fillMaxWidth()) { Text(if (checking) if (uk) "Перевірка…" else "Checking…" else if (uk) "Розблокувати" else "Unlock") }
            if (locked) { Spacer(Modifier.height(10.dp)); Text(if (uk) "Спробуйте через ${remaining / 1000}s" else "Try again in ${remaining / 1000}s") }
            error?.let { Spacer(Modifier.height(10.dp)); Text(it, color = MaterialTheme.colorScheme.error) }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun NotesScreen(vm: MainViewModel, state: UiState, touch: () -> Unit) {
    val uk = state.language == "uk"
    val notes by vm.notes.collectAsState()
    var query by rememberSaveable { mutableStateOf("") }
    var menu by remember { mutableStateOf(false) }
    var grid by rememberSaveable { mutableStateOf(true) }
    var decrypted by remember { mutableStateOf<Map<String, DecryptedNote>>(emptyMap()) }
    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    val context = LocalContext.current

    LaunchedEffect(notes, state.unlocked) {
        decrypted = buildMap {
            notes.forEach { note -> runCatching { vm.decrypt(note) }.getOrNull()?.let { put(note.id, it) } }
        }
    }
    val filtered = notes.filter { note ->
        val d = decrypted[note.id]
        query.isBlank() || d?.title?.contains(query, true) == true || d?.body?.contains(query, true) == true
    }

    @Composable fun NoteCardItem(note: NoteEntity) {
        val d = decrypted[note.id]
        Card(onClick = { vm.openEditor(note.id); touch() }, shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.fillMaxWidth().padding(14.dp)) {
                Text(highlightMatches(d?.title?.ifBlank { if (uk) "Без назви" else "Untitled" } ?: "••••••••", query, MaterialTheme.colorScheme.tertiaryContainer, MaterialTheme.colorScheme.onTertiaryContainer), style = MaterialTheme.typography.titleMedium, maxLines = 2)
                Spacer(Modifier.height(6.dp))
                Text(highlightMatches(d?.body?.replace("\n", " ")?.take(140) ?: "••••••••••••", query, MaterialTheme.colorScheme.tertiaryContainer, MaterialTheme.colorScheme.onTertiaryContainer), maxLines = 4, style = MaterialTheme.typography.bodyMedium)
                Spacer(Modifier.height(8.dp))
                Text(java.text.SimpleDateFormat("dd MMM", java.util.Locale.getDefault()).format(java.util.Date(note.updatedAt)), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Row(horizontalArrangement = Arrangement.End, modifier = Modifier.fillMaxWidth()) {
                    IconButton(onClick = { vm.deleteNote(note); scope.launch { snackbar.showSnackbar(if (uk) "Нотатку видалено" else "Note deleted") } }) { Icon(Icons.Default.Delete, if (uk) "Видалити" else "Delete") }
                    IconButton(onClick = { scope.launch { vm.export(note)?.let { copyToClipboard(context, it, state.clipboardClearSeconds) }; snackbar.showSnackbar(if (uk) "Експорт скопійовано" else "Export copied") } }) { Icon(Icons.Default.ContentCopy, if (uk) "Експорт" else "Export") }
                }
            }
        }
    }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text(if (uk) "Нотатки" else "Notes") },
                actions = {
                    IconButton(onClick = { grid = !grid }) { Icon(if (grid) Icons.Default.ViewList else Icons.Default.GridView, if (uk) "Змінити вигляд" else "Change layout") }
                    IconButton(onClick = { vm.lock(); touch() }) { Icon(Icons.Default.Lock, null) }
                    IconButton(onClick = { vm.navigate(Screen.SETTINGS); touch() }) { Icon(Icons.Default.Settings, null) }
                    Box {
                        IconButton(onClick = { menu = true }) { Icon(Icons.Default.MoreVert, null) }
                        DropdownMenu(menu, { menu = false }) {
                            DropdownMenuItem(text = { Text(if (uk) "Експорт усіх нотаток" else "Export all notes") }, onClick = { menu = false; scope.launch { vm.exportAll()?.let { copyToClipboard(context, it, state.clipboardClearSeconds) }; snackbar.showSnackbar(if (uk) "Експорт скопійовано" else "Export copied") } })
                            DropdownMenuItem(text = { Text(if (uk) "Імпорт" else "Import") }, onClick = { menu = false; vm.navigate(Screen.IMPORT) })
                            DropdownMenuItem(text = { Text(if (uk) "Довідка" else "Help") }, onClick = { menu = false; vm.navigate(Screen.HELP) })
                        }
                    }
                }
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(onClick = { vm.openEditor(null); touch() }, icon = { Icon(Icons.Default.Add, null) }, text = { Text(if (uk) "Нотатка" else "Note") })
        },
        snackbarHost = { SnackbarHost(snackbar) }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 12.dp)) {
            OutlinedTextField(query, { query = it; touch() }, leadingIcon = { Icon(Icons.Default.Search, null) }, label = { Text(if (uk) "Пошук у нотатках" else "Search notes") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp))
            if (filtered.isEmpty()) {
                Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                    Text(if (uk) "Немає нотаток" else "No notes", style = MaterialTheme.typography.titleLarge)
                    Spacer(Modifier.height(8.dp))
                    Text(if (uk) "Натисніть +, щоб створити першу нотатку." else "Press + to create your first note.")
                }
            } else if (grid) {
                LazyVerticalGrid(columns = GridCells.Fixed(2), contentPadding = PaddingValues(bottom = 100.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    gridItems(filtered, key = { it.id }) { note -> NoteCardItem(note) }
                }
            } else {
                LazyColumn(contentPadding = PaddingValues(bottom = 100.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(filtered, key = { it.id }) { note -> NoteCardItem(note) }
                }
            }
        }
    }
}

@Composable
private fun NoteEditorScreen(vm: MainViewModel, state: UiState, touch: () -> Unit) {
    val uk = state.language == "uk"
    val context = LocalContext.current
    var noteId by rememberSaveable(state.editingNoteId) { mutableStateOf(state.editingNoteId ?: java.util.UUID.randomUUID().toString()) }
    var title by remember(state.editingNoteId) { mutableStateOf("") }
    var body by remember(state.editingNoteId) { mutableStateOf("") }
    var loaded by remember(state.editingNoteId) { mutableStateOf(false) }
    var dirty by rememberSaveable(state.editingNoteId) { mutableStateOf(false) }
    var showHint by rememberSaveable { mutableStateOf(true) }
    data class EditorSnapshot(val title: String, val body: String)
    val history = remember(state.editingNoteId) { mutableStateListOf<EditorSnapshot>() }
    var historyIndex by remember(state.editingNoteId) { mutableIntStateOf(-1) }
    fun recordEdit(nextTitle: String, nextBody: String) {
        val snapshot = EditorSnapshot(nextTitle, nextBody)
        if (historyIndex >= 0 && history.getOrNull(historyIndex) == snapshot) return
        while (history.lastIndex > historyIndex) history.removeAt(history.lastIndex)
        history.add(snapshot)
        if (history.size > 100) history.removeAt(0)
        historyIndex = history.lastIndex
        title = nextTitle
        body = nextBody
        vm.updateEditorDraft(noteId, nextTitle, nextBody)
        dirty = true
        touch()
    }
    fun undoEdit() {
        if (historyIndex > 0) {
            historyIndex--
            title = history[historyIndex].title
            body = history[historyIndex].body
            dirty = true
            touch()
        }
    }
    fun redoEdit() {
        if (historyIndex < history.lastIndex) {
            historyIndex++
            title = history[historyIndex].title
            body = history[historyIndex].body
            dirty = true
            touch()
        }
    }

    DisposableEffect(noteId) {
        onDispose {
            if (dirty) vm.createOrUpdateNote(noteId, title, body)
        }
    }

    LaunchedEffect(state.editingNoteId) {
        loaded = false
        if (state.editingNoteId != null) {
            val note = vm.notes.value.firstOrNull { it.id == state.editingNoteId }
            val draft = state.editingNoteId?.let { vm.editorDraft(it) }
            val d = note?.let { vm.decrypt(it) }
            if (draft != null) { title = draft.title; body = draft.body }
            else if (d != null) { title = d.title; body = d.body }
        }
        history.clear()
        history.add(EditorSnapshot(title, body))
        historyIndex = 0
        dirty = false
        loaded = true
    }
    // Debounced autosave: no database write for every keystroke.
    LaunchedEffect(noteId, title, body, loaded) {
        if (loaded && dirty) {
            delay(700)
            vm.createOrUpdateNote(noteId, title, body)
            dirty = false
        }
    }

    Scaffold(topBar = {
        CenterAlignedTopAppBar(
            title = { Text(if (uk) "Нотатка" else "Note") },
            navigationIcon = { IconButton(onClick = { if (dirty || title.isNotBlank() || body.isNotBlank()) vm.createOrUpdateNote(noteId, title, body); vm.navigate(Screen.NOTES) }) { Icon(Icons.Default.ArrowBack, null) } },
            actions = {
                IconButton(onClick = { undoEdit() }, enabled = historyIndex > 0) { Icon(Icons.Default.Undo, if (uk) "Скасувати" else "Undo") }
                IconButton(onClick = { redoEdit() }, enabled = historyIndex in 0 until history.lastIndex) { Icon(Icons.Default.Redo, if (uk) "Повторити" else "Redo") }
                IconButton(onClick = { copyToClipboard(context, listOf(title, body).filter { it.isNotBlank() }.joinToString("\n\n"), state.clipboardClearSeconds) }) { Icon(Icons.Default.ContentCopy, if (uk) "Копіювати всю нотатку" else "Copy note") }
            }
        )
    }) { padding ->
        if (loaded) {
            Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp, vertical = 8.dp)) {
                if (showHint) {
                    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)) {
                        Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.HelpOutline, null); Spacer(Modifier.width(8.dp))
                            Text(if (uk) "Звичайний текстовий блокнот: додавайте сюди будь-яку кількість логінів, паролів і записів. Зміни зберігаються автоматично." else "A plain text notebook: add any number of logins, passwords and notes. Changes are saved automatically.", modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                            TextButton(onClick = { showHint = false }) { Text("OK") }
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                }
                OutlinedTextField(title, { recordEdit(it, body) }, label = { Text(if (uk) "Заголовок" else "Title") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(body, { recordEdit(title, it) }, label = { Text(if (uk) "Текст нотатки" else "Note text") }, minLines = 12, modifier = Modifier.weight(1f).fillMaxWidth())
                Spacer(Modifier.height(6.dp))
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                    Text(if (uk) "Автозбереження увімкнено" else "Autosave is on", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    TextButton(onClick = { copyToClipboard(context, listOf(title, body).filter { it.isNotBlank() }.joinToString("\n\n"), state.clipboardClearSeconds) }, enabled = title.isNotBlank() || body.isNotBlank()) { Icon(Icons.Default.ContentCopy, null); Spacer(Modifier.width(4.dp)); Text(if (uk) "Копіювати все" else "Copy all") }
                }
            }
        }
    }
}

@Composable
private fun SettingsScreen(vm: MainViewModel, state: UiState) {
    val uk = state.language == "uk"
    val context = LocalContext.current
    var showChangePin by remember { mutableStateOf(false) }
    var currentPin by remember { mutableStateOf("") }
    var masterKey by remember { mutableStateOf("") }
    var newPin by remember { mutableStateOf("") }
    val settingsScope = rememberCoroutineScope()
    var checkingCredentials by remember { mutableStateOf(false) }
    Scaffold(topBar = { CenterAlignedTopAppBar(title = { Text(if (uk) "Налаштування" else "Settings") }, navigationIcon = { IconButton(onClick = { vm.navigate(Screen.NOTES) }) { Icon(Icons.Default.ArrowBack, null) } }) }) { padding ->
        LazyColumn(Modifier.fillMaxSize().padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            item {
                Text(if (uk) "Режим шифрування" else "Encryption mode", style = MaterialTheme.typography.titleLarge)
                Text(if (state.cipherMode == "AES_GCM") "Надійний (AES-256-GCM)" else "Простий зсув (Цезар)")
                Text(if (state.cipherMode == "AES_GCM") if (uk) "Рекомендовано." else "Recommended." else if (uk) "НЕ захищає від серйозного злому. Лише для простих нотаток." else "NOT secure against serious attacks. Only for simple notes.", color = if (state.cipherMode == "AES_GCM") MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.error)
                Switch(checked = state.cipherMode == "AES_GCM", onCheckedChange = { vm.setCipherMode(if (it) "AES_GCM" else "CAESAR") })
            }
            item {
                Text(if (uk) "Автоблокування" else "Auto-lock")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf(1, 5, 15).forEach { m -> FilterChipLike("$m хв", state.autoLockMinutes == m) { vm.setAutoLock(m) } } }
            }
            item {
                Text(if (uk) "Очищення буфера обміну" else "Clipboard clearing")
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(30, 120, 300, 0).forEach { seconds ->
                        val label = when (seconds) { 30 -> "30 с"; 120 -> "2 хв"; 300 -> "5 хв"; else -> if (uk) "Ніколи" else "Never" }
                        FilterChipLike(label, state.clipboardClearSeconds == seconds) { vm.setClipboardClearSeconds(seconds) }
                    }
                }
                Text(if (uk) "Застосовується до копіювання кнопками застосунку. Системне меню Copy може обходити цей таймер." else "Applies to copies made with app buttons. Android's system Copy action may bypass this timer.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            item {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(if (uk) "Біометрія" else "Biometrics")
                        Text(if (uk) "Замінює PIN; головний ключ все одно потрібен." else "Replaces PIN; the master key is still required.")
                    }
                    Switch(checked = state.biometricEnabled, onCheckedChange = { vm.setBiometric(it) }, enabled = (context as? MainActivity)?.biometricAvailable() == true)
                }
            }
            item {
                Text(if (uk) "Мова" else "Language")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChipLike("Українська", state.language == "uk") { vm.setLanguage("uk") }
                    FilterChipLike("English", state.language == "en") { vm.setLanguage("en") }
                }
            }
            item { OutlinedButton(onClick = { showChangePin = true }, modifier = Modifier.fillMaxWidth()) { Text(if (uk) "Змінити PIN" else "Change PIN") } }
            item { OutlinedButton(onClick = { vm.navigate(Screen.EXPORT) }, modifier = Modifier.fillMaxWidth()) { Text(if (uk) "Експорт нотаток" else "Export notes") } }
            item { OutlinedButton(onClick = { vm.navigate(Screen.IMPORT) }, modifier = Modifier.fillMaxWidth()) { Text(if (uk) "Імпорт" else "Import") } }
            item { OutlinedButton(onClick = { vm.navigate(Screen.HELP) }, modifier = Modifier.fillMaxWidth()) { Text(if (uk) "Довідка" else "Help") } }
        }
    }
    if (showChangePin) {
        AlertDialog(onDismissRequest = { showChangePin = false }, title = { Text(if (uk) "Зміна PIN" else "Change PIN") }, text = {
            Column {
                OutlinedTextField(currentPin, { currentPin = it }, label = { Text(if (uk) "Старий PIN" else "Current PIN") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                OutlinedTextField(masterKey, { masterKey = it }, label = { Text(if (uk) "Парольна фраза або число" else "Passphrase or number") })
                OutlinedTextField(newPin, { if (it.all(Char::isDigit) && it.length <= 6) newPin = it }, label = { Text(if (uk) "Новий PIN" else "New PIN") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
            }
        }, confirmButton = {
            TextButton(onClick = {
                if (newPin.length in 4..6 && !checkingCredentials) {
                    checkingCredentials = true
                    settingsScope.launch {
                        val valid = vm.verifyCurrentCredentials(currentPin, masterKey)
                        if (valid) { vm.changePin(newPin); showChangePin = false }
                        checkingCredentials = false
                    }
                }
            }, enabled = !checkingCredentials) { Text(if (uk) "Зберегти" else "Save") }
        }, dismissButton = { TextButton(onClick = { showChangePin = false }) { Text(if (uk) "Скасувати" else "Cancel") } })
    }
}

@Composable
private fun FilterChipLike(label: String, selected: Boolean, onClick: () -> Unit) {
    if (selected) Button(onClick = onClick, contentPadding = PaddingValues(horizontal = 14.dp, vertical = 4.dp)) { Text(label) }
    else OutlinedButton(onClick = onClick, contentPadding = PaddingValues(horizontal = 14.dp, vertical = 4.dp)) { Text(label) }
}

@Composable
private fun HelpScreen(language: String, onBack: () -> Unit) {
    val uk = language == "uk"
    Scaffold(topBar = { CenterAlignedTopAppBar(title = { Text(if (uk) "Довідка" else "Help") }, navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) } }) }) { padding ->
        LazyColumn(Modifier.fillMaxSize().padding(padding).padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            item { Text(if (uk) "Як працює захист" else "How protection works", style = MaterialTheme.typography.headlineSmall) }
            item { Text(if (uk) "Заголовок і текст нотатки шифруються AES-256-GCM. Ключ виводиться з головного ключа через PBKDF2-HMAC-SHA256 (600 000 ітерацій) та унікальну випадкову сіль. PIN — окремий рівень входу й не є частиною ключа шифрування." else "Note title and body are encrypted with AES-256-GCM. The key is derived from the master key using PBKDF2-HMAC-SHA256 (600,000 iterations) and a unique random salt. The PIN is a separate sign-in layer and is not part of the encryption key.") }
            item { Text(if (uk) "У базі даних зберігаються лише зашифровані заголовки й тексти. Без головного ключа видно лише шифротекст." else "Only encrypted titles and bodies are stored in the database. Without the master key, only ciphertext is visible.") }
            item { Text(if (uk) "Головний ключ не відновлюється. Зміна PIN перебудовує ключ і перешифровує наявні нотатки." else "The master key cannot be recovered. Changing the PIN re-encrypts existing notes under a new derived key.") }
            item { Text(if (uk) "Режим Цезаря слабкий і не призначений для паролів або важливих секретів." else "Caesar mode is weak and is not intended for passwords or important secrets.") }
            item { Text(if (uk) "Застосунок не має INTERNET-дозволу, реклами, аналітики, трекерів чи мережевих викликів." else "The app has no INTERNET permission, ads, analytics, trackers or network calls.") }
        }
    }
}

@Composable
private fun ExportScreen(vm: MainViewModel, state: UiState, onBack: () -> Unit) {
    val uk = state.language == "uk"
    val notes by vm.notes.collectAsState()
    var decrypted by remember { mutableStateOf<Map<String, DecryptedNote>>(emptyMap()) }
    var output by remember { mutableStateOf("") }
    val context = LocalContext.current
    val exportScope = rememberCoroutineScope()
    LaunchedEffect(notes) { decrypted = buildMap { notes.forEach { runCatching { vm.decrypt(it) }.getOrNull()?.let { d -> put(d.id, d) } } } }
    Scaffold(topBar = { CenterAlignedTopAppBar(title = { Text(if (uk) "Експорт" else "Export") }, navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) } }) }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            Text(if (uk) "Експорт створює зашифрований Base64-рядок. Його можна перенести без мережі." else "Export creates an encrypted Base64 string that can be transferred without a network.")
            Spacer(Modifier.height(10.dp))
            Button(onClick = { exportScope.launch { output = vm.exportAll() ?: "" } }, modifier = Modifier.fillMaxWidth()) { Text(if (uk) "Експортувати всі" else "Export all") }
            Spacer(Modifier.height(10.dp))
            LazyColumn(Modifier.weight(1f)) {
                items(notes, key = { it.id }) { note ->
                    val d = decrypted[note.id]
                    OutlinedButton(onClick = { exportScope.launch { output = vm.export(note) ?: "" } }, modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp)) { Text(d?.title ?: "••••••••") }
                }
            }
            if (output.isNotBlank()) {
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(output, {}, readOnly = true, minLines = 5, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = { copyToClipboard(context, output, state.clipboardClearSeconds) }, modifier = Modifier.fillMaxWidth()) { Text(if (uk) "Скопіювати зашифрований текст" else "Copy encrypted text") }
                Spacer(Modifier.height(6.dp))
                Text(if (uk) "Скопіюйте цей текст і вставте його в іншому екземплярі застосунку, ввівши той самий головний ключ." else "Copy this text and paste it into another instance of the app using the same master key.")
            }
        }
    }
}

@Composable
private fun ImportScreen(vm: MainViewModel, state: UiState, onBack: () -> Unit) {
    val uk = state.language == "uk"
    var text by rememberSaveable { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    Scaffold(topBar = { CenterAlignedTopAppBar(title = { Text(if (uk) "Імпорт" else "Import") }, navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) } }) }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            Text(if (uk) "Вставте зашифрований Base64-рядок. Потрібен той самий головний ключ." else "Paste the encrypted Base64 string. The same master key is required.")
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(text, { text = it }, minLines = 10, label = { Text(if (uk) "Зашифрований текст" else "Encrypted text") }, modifier = Modifier.fillMaxWidth().weight(1f))
            Spacer(Modifier.height(10.dp))
            val scope = rememberCoroutineScope()
            Button(onClick = { scope.launch { val result = vm.importText(text); if (result.isSuccess) onBack() else error = if (uk) "Не вдалося імпортувати. Перевірте рядок і головний ключ." else "Import failed. Check the string and master key." } }, enabled = text.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text(if (uk) "Імпортувати" else "Import") }
            error?.let { Spacer(Modifier.height(8.dp)); Text(it, color = MaterialTheme.colorScheme.error) }
        }
    }
}

private fun highlightMatches(text: String, query: String, background: androidx.compose.ui.graphics.Color, foreground: androidx.compose.ui.graphics.Color): AnnotatedString {
    if (query.isBlank()) return AnnotatedString(text)
    return buildAnnotatedString {
        var cursor = 0
        while (cursor < text.length) {
            val start = text.indexOf(query, cursor, ignoreCase = true)
            if (start < 0) {
                append(text.substring(cursor))
                break
            }
            if (start > cursor) append(text.substring(cursor, start))
            val end = (start + query.length).coerceAtMost(text.length)
            pushStyle(SpanStyle(background = background, color = foreground))
            append(text.substring(start, end))
            pop()
            cursor = end
        }
    }
}

private fun copyToClipboard(context: Context, value: String, clearAfterSeconds: Int) {
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    val clipLabel = "Encrypted Notebook:${java.util.UUID.randomUUID()}"
    val clip = ClipData.newPlainText(clipLabel, value)
    clipboard.setPrimaryClip(clip)
    if (clearAfterSeconds > 0) {
        Handler(Looper.getMainLooper()).postDelayed({
            runCatching {
                val isOurClip = clipboard.primaryClipDescription?.label?.toString() == clipLabel
                if (isOurClip && clipboard.primaryClip?.getItemAt(0)?.coerceToText(context)?.toString() == value) {
                    clipboard.setPrimaryClip(ClipData.newPlainText("", ""))
                }
            }
        }, clearAfterSeconds * 1000L)
    }
}
