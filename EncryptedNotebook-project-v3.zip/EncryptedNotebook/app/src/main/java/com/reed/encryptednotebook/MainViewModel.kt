package com.reed.encryptednotebook

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.reed.encryptednotebook.data.DecryptedNote
import com.reed.encryptednotebook.data.NoteEntity
import com.reed.encryptednotebook.data.NoteRepository
import com.reed.encryptednotebook.security.KeyDerivation
import com.reed.encryptednotebook.security.CryptoSession
import com.reed.encryptednotebook.security.SecurityRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val security: SecurityRepository = (app as NotebookApplication).security
    private val repository: NoteRepository = (app as NotebookApplication).notes

    private val _notes = MutableStateFlow<List<NoteEntity>>(emptyList())
    val notes: StateFlow<List<NoteEntity>> = _notes.asStateFlow()

    private val _state = MutableStateFlow(
        UiState(
            configured = security.isConfigured,
            screen = if (security.isConfigured) Screen.PIN else Screen.ONBOARDING,
            autoLockMinutes = security.autoLockMinutes(),
            clipboardClearSeconds = security.clipboardClearSeconds(),
            biometricEnabled = security.biometricEnabled(),
            language = security.language(),
            cipherMode = security.cipherMode()
        )
    )
    val state: StateFlow<UiState> = _state.asStateFlow()

    private var cryptoSession: CryptoSession? = null
    private var pinVerifiedForSession: Boolean = false
    private var masterKeyForSession: String? = null
    private var setupPin: String? = null
    private var backgroundAtElapsed: Long? = null
    private var screenBeforeBackground: Screen = Screen.NOTES
    private var pendingDraft: EditorDraft? = null
    private val saveMutex = Mutex()

    init {
        if (security.isConfigured) observeNotes()
    }

    private fun observeNotes() {
        viewModelScope.launch {
            repository.observeAll().collect { _notes.value = it }
        }
    }

    fun navigate(screen: Screen) {
        _state.value = _state.value.copy(screen = screen)
    }

    fun openEditor(id: String?) {
        if (pendingDraft?.id != id) pendingDraft = null
        _state.value = _state.value.copy(screen = Screen.EDIT_NOTE, editingNoteId = id)
    }

    fun editorDraft(id: String): EditorDraft? = pendingDraft?.takeIf { it.id == id }

    fun updateEditorDraft(id: String, title: String, body: String) {
        pendingDraft = EditorDraft(id, title, body)
    }

    fun beginSetup() {
        setupPin = null
        _state.value = _state.value.copy(screen = Screen.SETUP_PIN)
    }

    fun setSetupPin(pin: String) {
        setupPin = pin
        _state.value = _state.value.copy(screen = Screen.SETUP_KEY)
    }

    fun finishSetup(masterKey: String) {
        val pin = setupPin ?: return
        viewModelScope.launch {
            withContext(Dispatchers.Default) { security.configure(pin, masterKey) }
            setupPin = null
            pinVerifiedForSession = false
            masterKeyForSession = null
            cryptoSession?.wipe()
            cryptoSession = null
            _state.value = _state.value.copy(configured = true, screen = Screen.WARNING)
            observeNotes()
        }
    }

    fun pinLockRemaining(): Long = maxOf(0L, security.pinLockUntil() - System.currentTimeMillis())
    fun keyLockRemaining(): Long = maxOf(0L, security.keyLockUntil() - System.currentTimeMillis())

    fun verifyPin(pin: String): PinResult {
        val now = System.currentTimeMillis()
        if (security.pinLockUntil() > now) return PinResult.Locked(security.pinLockUntil())
        return if (security.verifyPin(pin)) {
            security.clearPinFailures()
            pinVerifiedForSession = true
            _state.value = _state.value.copy(screen = Screen.LOCKED_NOTES, pinError = null)
            PinResult.Success
        } else {
            val failures = security.recordPinFailure()
            if (security.pinLockUntil() > System.currentTimeMillis()) PinResult.Locked(security.pinLockUntil())
            else PinResult.Wrong(failures)
        }
    }

    fun unlockWithBiometric() {
        if (security.storedPinForBiometric() == null) return
        pinVerifiedForSession = true
        _state.value = _state.value.copy(screen = Screen.LOCKED_NOTES, pinError = null)
    }

    suspend fun verifyMasterKey(masterKey: String): KeyResult = withContext(Dispatchers.Default) {
        val now = System.currentTimeMillis()
        if (security.keyLockUntil() > now) return@withContext KeyResult.Locked(security.keyLockUntil())
        if (!pinVerifiedForSession) return@withContext KeyResult.Wrong(0)
        val salt = security.noteSalt() ?: return@withContext KeyResult.Wrong(0)
        val valid = security.verifyMasterKey(masterKey)
        val candidate = if (valid) KeyDerivation.deriveNoteKey(masterKey, salt) else ByteArray(0)
        if (!valid) {
            val failures = security.recordKeyFailure()
            if (security.keyLockUntil() > System.currentTimeMillis()) return@withContext KeyResult.Locked(security.keyLockUntil())
            return@withContext KeyResult.Wrong(failures)
        }
        cryptoSession = CryptoSession(candidate, byteArrayOf(KeyDerivation.masterId(masterKey).toByte()))
        masterKeyForSession = masterKey
        security.clearKeyFailures()
        _state.value = _state.value.copy(screen = Screen.NOTES, keyError = null, unlocked = true)
        return@withContext KeyResult.Success
    }

    fun onAppBackgrounded() {
        if (!_state.value.unlocked || _state.value.screen == Screen.BACKGROUND) return
        screenBeforeBackground = _state.value.screen
        backgroundAtElapsed = android.os.SystemClock.elapsedRealtime()
        _state.value = _state.value.copy(screen = Screen.BACKGROUND)
    }

    fun onAppForegrounded() {
        val started = backgroundAtElapsed ?: return
        backgroundAtElapsed = null
        val elapsed = android.os.SystemClock.elapsedRealtime() - started
        if (elapsed >= _state.value.autoLockMinutes * 60_000L) {
            lock()
        } else if (_state.value.unlocked) {
            _state.value = _state.value.copy(screen = screenBeforeBackground)
        }
    }

    fun lock() {
        backgroundAtElapsed = null
        val draft = pendingDraft
        val sessionCopy = cryptoSession?.let { CryptoSession(it.aesKey.copyOf(), it.caesarKey.copyOf()) }
        if (draft != null && sessionCopy != null) {
            viewModelScope.launch {
                try {
                    saveMutex.withLock {
                        withContext(Dispatchers.Default) {
                            repository.save(draft.id, draft.title, draft.body, _state.value.cipherMode, sessionCopy)
                        }
                    }
                } finally {
                    sessionCopy.wipe()
                }
            }
        } else {
            sessionCopy?.wipe()
        }
        pendingDraft = null
        cryptoSession?.wipe()
        cryptoSession = null
        pinVerifiedForSession = false
        masterKeyForSession = null
        _state.value = _state.value.copy(screen = Screen.PIN, unlocked = false, editingNoteId = null)
    }

    fun createOrUpdateNote(id: String?, title: String, body: String) {
        val session = cryptoSession ?: return
        val sessionCopy = CryptoSession(session.aesKey.copyOf(), session.caesarKey.copyOf())
        if (id != null) pendingDraft = EditorDraft(id, title, body)
        viewModelScope.launch {
            try {
                saveMutex.withLock {
                    withContext(Dispatchers.Default) { repository.save(id, title, body, _state.value.cipherMode, sessionCopy) }
                }
                if (id != null && pendingDraft == EditorDraft(id, title, body)) pendingDraft = null
            } finally {
                sessionCopy.wipe()
            }
        }
    }

    fun deleteNote(note: NoteEntity) { viewModelScope.launch { repository.delete(note) } }

    suspend fun decrypt(note: NoteEntity): DecryptedNote? = withContext(Dispatchers.Default) { cryptoSession?.let { repository.decrypt(note, it) } }

    suspend fun export(note: NoteEntity): String? = withContext(Dispatchers.Default) {
        val session = cryptoSession ?: return@withContext null
        val master = masterKeyForSession ?: return@withContext null
        NoteRepository.packExport(listOf(repository.decrypt(note, session)), master)
    }

    suspend fun exportAll(): String? = withContext(Dispatchers.Default) {
        val session = cryptoSession ?: return@withContext null
        val master = masterKeyForSession ?: return@withContext null
        val decrypted = _notes.value.mapNotNull { runCatching { repository.decrypt(it, session) }.getOrNull() }
        NoteRepository.packExport(decrypted, master)
    }

    suspend fun importText(text: String): Result<Unit> = withContext(Dispatchers.Default) {
        val session = cryptoSession ?: return@withContext Result.failure(IllegalStateException("Locked"))
        val master = masterKeyForSession ?: return@withContext Result.failure(IllegalStateException("Locked"))
        try {
            val imported = NoteRepository.unpackExport(text.trim(), master)
            withContext(Dispatchers.IO) { imported.forEach { repository.importNote(it, session) } }
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun setAutoLock(minutes: Int) {
        security.setAutoLockMinutes(minutes)
        _state.value = _state.value.copy(autoLockMinutes = minutes)
    }

    fun setClipboardClearSeconds(seconds: Int) {
        security.setClipboardClearSeconds(seconds)
        _state.value = _state.value.copy(clipboardClearSeconds = seconds)
    }

    fun setBiometric(enabled: Boolean) {
        security.setBiometric(enabled)
        _state.value = _state.value.copy(biometricEnabled = enabled)
    }

    fun setLanguage(language: String) {
        security.setLanguage(language)
        _state.value = _state.value.copy(language = language)
    }

    fun setCipherMode(mode: String) {
        security.setCipherMode(mode)
        _state.value = _state.value.copy(cipherMode = mode)
    }

    suspend fun verifyCurrentCredentials(pin: String, masterKey: String): Boolean = withContext(Dispatchers.Default) {
        security.verifyPin(pin) && security.verifyMasterKey(masterKey)
    }

    fun changePin(newPin: String) {
        val oldSession = cryptoSession ?: return
        val oldSessionCopy = CryptoSession(oldSession.aesKey.copyOf(), oldSession.caesarKey.copyOf())
        val master = masterKeyForSession ?: return
        viewModelScope.launch {
            val newSession = withContext(Dispatchers.Default) {
                security.changePin(newPin)
                val salt = security.noteSalt() ?: return@withContext null
                CryptoSession(
                    KeyDerivation.deriveNoteKey(master, salt),
                    byteArrayOf(KeyDerivation.masterId(master).toByte())
                )
            } ?: return@launch
            val notes = _notes.value.toList()
            withContext(Dispatchers.Default) {
                notes.forEach { note ->
                    val plain = runCatching { repository.decrypt(note, oldSessionCopy) }.getOrNull() ?: return@forEach
                    repository.save(note.id, plain.title, plain.body, note.cipherMode, newSession)
                }
            }
            oldSessionCopy.wipe()
            cryptoSession?.wipe()
            cryptoSession = newSession
            pinVerifiedForSession = true
        }
    }

    override fun onCleared() {
        cryptoSession?.wipe()
        cryptoSession = null
        pendingDraft = null
        super.onCleared()
    }
}

data class EditorDraft(val id: String, val title: String, val body: String)

enum class Screen { ONBOARDING, SETUP_PIN, SETUP_KEY, WARNING, PIN, LOCKED_NOTES, MASTER_KEY, NOTES, EDIT_NOTE, SETTINGS, HELP, EXPORT, IMPORT, BACKGROUND }

data class UiState(
    val configured: Boolean,
    val screen: Screen,
    val unlocked: Boolean = false,
    val pinError: String? = null,
    val keyError: String? = null,
    val autoLockMinutes: Int = 1,
    val clipboardClearSeconds: Int = 120,
    val biometricEnabled: Boolean = false,
    val language: String = "uk",
    val cipherMode: String = "AES_GCM",
    val editingNoteId: String? = null
)

sealed interface PinResult {
    data object Success : PinResult
    data class Wrong(val failures: Int) : PinResult
    data class Locked(val until: Long) : PinResult
}

sealed interface KeyResult {
    data object Success : KeyResult
    data class Wrong(val failures: Int) : KeyResult
    data class Locked(val until: Long) : KeyResult
}
