package com.reed.encryptednotebook.data

import android.util.Base64
import com.reed.encryptednotebook.security.AesGcmCipher
import com.reed.encryptednotebook.security.CaesarCipher
import com.reed.encryptednotebook.security.CipherMethod
import com.reed.encryptednotebook.security.Ciphertext
import com.reed.encryptednotebook.security.CryptoSession
import com.reed.encryptednotebook.security.KeyDerivation
import kotlinx.coroutines.flow.Flow
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

class NoteRepository(private val db: AppDatabase) {
    private val aes = AesGcmCipher()
    private val caesar = CaesarCipher()

    fun observeAll(): Flow<List<NoteEntity>> = db.noteDao().observeAll()
    suspend fun get(id: String): NoteEntity? = db.noteDao().getById(id)
    suspend fun delete(note: NoteEntity) = db.noteDao().delete(note)

    suspend fun save(id: String?, title: String, body: String, mode: String, session: CryptoSession, now: Long = System.currentTimeMillis()) {
        val cipher = method(mode)
        val encryptedTitle = cipher.encrypt(title, session.keyFor(mode))
        val encryptedBody = cipher.encrypt(body, session.keyFor(mode))
        val existing = id?.let { db.noteDao().getById(it) }
        val note = NoteEntity(
            id = existing?.id ?: (id ?: UUID.randomUUID().toString()),
            titleCipher = encryptedTitle.payload,
            titleNonce = encryptedTitle.nonce ?: "",
            bodyCipher = encryptedBody.payload,
            bodyNonce = encryptedBody.nonce,
            passwordCipher = "",
            passwordNonce = null,
            tagsCipher = "",
            tagsNonce = null,
            createdAt = existing?.createdAt ?: now,
            updatedAt = now,
            cipherMode = mode
        )
        if (existing == null) db.noteDao().insert(note) else db.noteDao().update(note)
    }

    fun decrypt(note: NoteEntity, session: CryptoSession): DecryptedNote {
        val cipher = method(note.cipherMode)
        return DecryptedNote(
            id = note.id,
            title = cipher.decrypt(Ciphertext(note.titleCipher, note.titleNonce), session.keyFor(note.cipherMode)),
            body = cipher.decrypt(Ciphertext(note.bodyCipher, note.bodyNonce), session.keyFor(note.cipherMode)),
            createdAt = note.createdAt,
            updatedAt = note.updatedAt
        )
    }

    fun method(mode: String): CipherMethod = if (mode == "CAESAR") caesar else aes

    suspend fun importNote(imported: ImportedNote, session: CryptoSession) {
        save(null, imported.title, imported.body, "AES_GCM", session, imported.updatedAt)
    }

    companion object {
        private fun exportKey(masterKey: String, salt: ByteArray): ByteArray = KeyDerivation.deriveNoteKey("ENB-EXPORT-V2|$masterKey", salt)

        fun packExport(notes: List<DecryptedNote>, masterKey: String): String {
            val salt = KeyDerivation.randomSalt()
            val array = JSONArray()
            notes.forEach { note ->
                array.put(JSONObject().apply {
                    put("title", note.title)
                    put("body", note.body)
                    put("createdAt", note.createdAt)
                    put("updatedAt", note.updatedAt)
                })
            }
            val payload = JSONObject().apply { put("format", "ENB2"); put("notes", array) }.toString()
            val cipher = AesGcmCipher().encrypt(payload, exportKey(masterKey, salt))
            val packed = "ENB2|${Base64.encodeToString(salt, Base64.NO_WRAP)}|${cipher.nonce}|${cipher.payload}"
            return Base64.encodeToString(packed.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
        }

        fun unpackExport(value: String, masterKey: String): List<ImportedNote> {
            val raw = Base64.decode(value, Base64.NO_WRAP).toString(Charsets.UTF_8)
            val parts = raw.split("|", limit = 4)
            val root = if (parts.firstOrNull() == "ENB1") {
                require(parts.size == 3) { "Invalid legacy export" }
                val legacyKey = KeyDerivation.sha256("ENB-EXPORT-V1|$masterKey")
                val legacyPlain = AesGcmCipher().decrypt(Ciphertext(parts[2], parts[1]), legacyKey)
                JSONObject(legacyPlain).also { require(it.optString("format") == "ENB1") }
            } else {
                require(parts.size == 4 && parts[0] == "ENB2") { "Unsupported or invalid export format" }
                val salt = Base64.decode(parts[1], Base64.NO_WRAP)
                require(salt.size == 16) { "Invalid export salt" }
                val plain = AesGcmCipher().decrypt(Ciphertext(parts[3], parts[2]), exportKey(masterKey, salt))
                JSONObject(plain).also { require(it.optString("format") == "ENB2") }
            }
            val array = root.getJSONArray("notes")
            return buildList {
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    add(ImportedNote(
                        createdAt = obj.optLong("createdAt", System.currentTimeMillis()),
                        updatedAt = obj.optLong("updatedAt", System.currentTimeMillis()),
                        title = obj.optString("title"),
                        body = obj.optString("body")
                    ))
                }
            }
        }
    }
}

data class DecryptedNote(val id: String, val title: String, val body: String, val createdAt: Long, val updatedAt: Long)
data class ImportedNote(val createdAt: Long, val updatedAt: Long, val title: String, val body: String)
