package com.reed.encryptednotebook.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * The UI/data model is title + body only. password/tags columns are retained as
 * empty legacy columns so existing Room v1 installations do not fail schema validation.
 */
@Entity(tableName = "notes")
data class NoteEntity(
    @PrimaryKey val id: String,
    val titleCipher: String,
    val titleNonce: String?,
    val bodyCipher: String,
    val bodyNonce: String?,
    @Deprecated("Legacy schema compatibility only; never populated with user data") val passwordCipher: String,
    @Deprecated("Legacy schema compatibility only; always null") val passwordNonce: String?,
    @Deprecated("Legacy schema compatibility only; never populated with user data") val tagsCipher: String,
    @Deprecated("Legacy schema compatibility only; always null") val tagsNonce: String?,
    val createdAt: Long,
    val updatedAt: Long,
    val cipherMode: String
)
