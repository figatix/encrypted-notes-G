package com.reed.encryptednotebook.security

import java.security.SecureRandom
import java.util.Base64
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

class AesGcmCipher : CipherMethod {
    override val id = "AES_GCM"
    override val displayNameUk = "Надійний (AES-256-GCM)"
    override val displayNameEn = "Strong (AES-256-GCM)"

    override fun encrypt(plainText: String, key: ByteArray): Ciphertext {
        require(key.size == 32) { "AES-256 requires a 32-byte key" }
        val nonce = ByteArray(12).also { SecureRandom().nextBytes(it) }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(128, nonce))
        val encrypted = cipher.doFinal(plainText.toByteArray(Charsets.UTF_8))
        return Ciphertext(
            payload = Base64.getEncoder().withoutPadding().encodeToString(encrypted),
            nonce = Base64.getEncoder().withoutPadding().encodeToString(nonce)
        )
    }

    override fun decrypt(ciphertext: Ciphertext, key: ByteArray): String {
        require(key.size == 32) { "AES-256 requires a 32-byte key" }
        val nonce = Base64.getDecoder().decode(ciphertext.nonce ?: error("Missing nonce"))
        val encrypted = Base64.getDecoder().decode(ciphertext.payload)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(128, nonce))
        return cipher.doFinal(encrypted).toString(Charsets.UTF_8)
    }
}
