package com.reed.encryptednotebook.security

import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

object KeyDerivation {
    private const val ITERATIONS = 600_000
    private const val KEY_BITS = 256

    fun randomSalt(size: Int = 16): ByteArray = ByteArray(size).also { SecureRandom().nextBytes(it) }

    fun deriveNoteKey(masterKey: String, salt: ByteArray): ByteArray {
        val normalized = masterKey.trim().toCharArray()
        val spec = PBEKeySpec(normalized, salt, ITERATIONS, KEY_BITS)
        return try {
            SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
        } finally {
            spec.clearPassword()
            normalized.fill('\u0000')
        }
    }

    fun deriveVerifier(masterKey: String, salt: ByteArray): ByteArray = deriveNoteKey("ENB-VERIFY-V1|${masterKey.trim()}", salt)

    fun sha256(value: String): ByteArray = MessageDigest.getInstance("SHA-256").digest(value.toByteArray(Charsets.UTF_8))

    fun constantTimeEquals(a: ByteArray, b: ByteArray): Boolean = MessageDigest.isEqual(a, b)

    fun masterId(masterKey: String): Int {
        masterKey.toLongOrNull()?.let { return Math.floorMod(it, 31L).toInt() }
        val value = MessageDigest.getInstance("SHA-256").digest(masterKey.toByteArray(Charsets.UTF_8))
        return ((value[0].toInt() and 0xff) % 31)
    }
}
