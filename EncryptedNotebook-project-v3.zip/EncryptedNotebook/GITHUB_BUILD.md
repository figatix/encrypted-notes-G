# GitHub Actions workflow (copy to `.github/workflows/build.yml`)

The workflow below is also included at `.github/workflows/build.yml` inside the ZIP. If the repository already has an older workflow at the root, replace its contents with this YAML using GitHub's web editor.

```yaml
name: Build Encrypted Notebook APK

on:
  push:
  workflow_dispatch:

permissions:
  contents: read

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - name: Checkout repository
        uses: actions/checkout@v4

      - name: Extract project archive
        run: |
          ARCHIVE=""
          for candidate in EncryptedNotebook-project-v3.zip EncryptedNotebook-project-phone-v2.zip EncryptedNotebook-project-phone.zip EncryptedNotebook-project.zip; do
            if [ -f "$candidate" ]; then ARCHIVE="$candidate"; break; fi
          done
          if [ -z "$ARCHIVE" ]; then
            echo "Project ZIP not found in repository root" >&2
            ls -la
            exit 1
          fi
          unzip -oq "$ARCHIVE" -d extracted
          if [ -d extracted/EncryptedNotebook ]; then
            echo "PROJECT_DIR=extracted/EncryptedNotebook" >> "$GITHUB_ENV"
          elif [ -f extracted/settings.gradle.kts ]; then
            echo "PROJECT_DIR=extracted" >> "$GITHUB_ENV"
          else
            echo "Could not locate settings.gradle.kts after extraction" >&2
            find extracted -maxdepth 4 -type f | head -100
            exit 1
          fi

      - name: Set up JDK 17
        uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: '17'

      - name: Set up Android SDK
        uses: android-actions/setup-android@v3

      - name: Install Android SDK packages
        run: |
          sdkmanager "platforms;android-37" "build-tools;36.0.0"
          yes | sdkmanager --licenses >/dev/null || true

      - name: Set up Gradle
        uses: gradle/actions/setup-gradle@v4
        with:
          gradle-version: '9.7.0'

      - name: Run unit tests and build debug APK
        run: gradle -p "$PROJECT_DIR" testDebugUnitTest assembleDebug --no-daemon --stacktrace

      - name: Upload debug APK
        uses: actions/upload-artifact@v4
        with:
          name: encrypted-notebook-debug-apk
          path: ${{ env.PROJECT_DIR }}/app/build/outputs/apk/debug/app-debug.apk
          if-no-files-found: error
          retention-days: 14
```
