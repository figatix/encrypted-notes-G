# Encrypted Notebook v4

Offline Android notebook for private notes and credentials.

## Build

- Android Gradle Plugin: 9.3.1
- Gradle: 9.7.0 (provided by the included GitHub Actions workflow)
- JDK: 17
- Kotlin built into AGP 9.3.1; Compose compiler plugin 2.4.21
- KSP: 2.3.12
- compileSdk / targetSdk: 37
- minSdk: 26

This project does not include a Gradle wrapper. The provided GitHub Actions workflow installs the pinned Gradle version. No Android Studio or local SDK setup is needed to produce the debug APK through GitHub Actions.

## Product and security notes

See `ARCHITECTURE.md` for the agreed feature set, key hierarchy, encryption, lifecycle, clipboard behavior, export formats, limitations, and migration notes.

This is a development build, not a security-audited password manager. The biometric prompt is currently a convenience gate, not a biometric-bound cryptographic key operation.
