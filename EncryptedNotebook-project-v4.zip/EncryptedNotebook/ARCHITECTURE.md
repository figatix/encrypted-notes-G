# Encrypted Notebook — architecture v4

## Product model

- Offline Android notebook, Android 8.0 / API 26 and newer.
- A note contains exactly two user-facing fields: `title` and free-form `body`.
- The body may contain any number of credentials, passwords, access codes, URLs, or ordinary notes. There are no password-specific fields or password generator in the note editor.
- Home screen: note cards; two-column grid or list; search across title and body with matching text highlighted.
- Editor: debounced autosave (700 ms), copy whole note, normal Android text selection/copy for fragments, Undo/Redo history capped at 100 snapshots per editor session.

## Credential and key hierarchy

1. **PIN (4–6 digits)** gates entry to the app. Five failed attempts trigger a 10-minute PIN lockout.
2. **Master key** is independent from the PIN. It can be a passphrase or a numeric string, minimum 8 characters. Five failed attempts trigger a separate 10-minute lockout.
3. A random 16-byte master-verifier salt and PBKDF2-HMAC-SHA256 verifier are stored as metadata encrypted by an Android Keystore AES-256-GCM key. The master key itself is not persisted.
4. A separate random 16-byte note salt is generated at setup. PBKDF2-HMAC-SHA256 (600,000 iterations, 256-bit output) derives the note encryption key from the master key only. PIN is deliberately not part of this derivation, so changing the PIN does not change the data-encryption key.
5. The derived key is held in memory for the unlocked session and overwritten when locking. This is best-effort memory hygiene; managed runtimes can retain copies temporarily.
6. A short numeric key is weak even with PBKDF2. Prefer a long, unique passphrase; if numeric-only, use a random value of at least 16 digits. The app enforces only an 8-character minimum, not high entropy.

## Data encryption

- AES-256-GCM (`AES/GCM/NoPadding`), 96-bit random nonce per encrypted field, 128-bit authentication tag.
- Title and body are encrypted separately. Only ciphertext, nonce, UUID, timestamps, and cipher-mode metadata are persisted in Room.
- PIN/master verifier metadata is encrypted at rest with a non-exportable Android Keystore AES key.
- Caesar mode is an educational obfuscation mode only. It is not cryptographic protection and must never be used for secrets. AES-GCM is the default.
- No plaintext secret logging is permitted.

## Lifecycle and locking

- `FLAG_SECURE` blocks screenshots and most recents thumbnails.
- When the Activity leaves the foreground, the UI is replaced immediately with an empty cover. If the app returns before the configured 1/5/15-minute timer expires, the current decrypted session is restored. If the timer expires, the session key is wiped and the PIN screen is shown; the master key is required again after PIN entry.
- Process death clears the in-memory ViewModel/session. The editor does not use `rememberSaveable` for decrypted title/body text.
- Autosave is debounced by 700 ms. Save and crypto work are moved off the main thread.

## Copy / clipboard

- App-controlled whole-note and export copies are tagged with a unique app clipboard label and can be cleared after 30 seconds, 2 minutes (default), 5 minutes, or never. The timer clears only that exact still-current clip, so a later copy—even of identical text—is not erased by an earlier timer.
- The Android system selection toolbar's Copy action is controlled by the OS/Compose text field and does not pass through the app's copy helper. Therefore the app cannot reliably enforce its timer on those system-originated copies. The clipboard may also be read by other apps according to Android's clipboard behavior.

## Export format

- ENB2 is an encrypted portable payload: independent random salt, PBKDF2-HMAC-SHA256 key derivation from the master key, then AES-256-GCM. It does not depend on the local PIN and can be imported on a device with a different PIN.
- ENB1 export strings from the previous prototype are accepted for import using the legacy SHA-256 export-key scheme. Newly created exports always use ENB2.
- Export temporarily materializes plaintext in process memory. Share/copy the resulting ciphertext, not decrypted JSON.

## Offline and platform constraints

- No `INTERNET` permission; no ads, analytics, trackers, telemetry, or network SDKs.
- Android backup is disabled in the manifest and backup rules.
- Room access and expensive cryptography are not intended to run on the main thread.
- Unit tests cover AES-GCM roundtrip/authentication, verifier behavior, and Caesar demo roundtrip.

## Known limitations / release gates

- This is a development build, not a security-audited password manager. Device compromise, root, malware, keylogging, or memory inspection while unlocked can expose data.
- PBKDF2 is deliberately used per the project specification; Argon2id would generally be preferable against GPU-assisted guessing, but needs a suitable maintained implementation and compatibility review.
- Biometric sign-in is currently an app-level BiometricPrompt gate that releases the PIN stored encrypted by Android Keystore; it is not yet a Keystore key whose cryptographic operation itself requires biometric authentication. Treat it as convenience, not as an independent hardware-backed key factor.
- The prototype's Room v1 schema retains deprecated empty password/tags columns for schema compatibility; they are never populated with note data and are not exposed in the model or UI.
- Before production release: add instrumentation tests on API 26 and current Android, review biometric flow, clipboard behavior, export/import limits, lockout persistence, lifecycle races, and perform an independent cryptographic/security review.
