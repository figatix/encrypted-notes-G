# GitHub Actions build — Encrypted Notebook v4

1. Put `EncryptedNotebook-project-v4.zip` in the repository root.
2. Put the supplied `build.yml` at `.github/workflows/build.yml` (replace the old file completely).
3. Commit both files. GitHub Actions starts on push.
4. Open **Actions → Build Encrypted Notebook APK → Test and build APK**.
5. When the run is green, download artifact `encrypted-notebook-v4-debug-apk`.

The workflow intentionally accepts only the v4 archive. It checks ZIP integrity and the expected project paths before installing dependencies. It uses JDK 17 and Gradle 9.7.0. The project uses AGP 9.3.1 with AGP's built-in Kotlin support, so the legacy `org.jetbrains.kotlin.android` plugin is not applied.
