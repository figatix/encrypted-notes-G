package com.reed.encryptednotebook.security

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Test

class CryptoTest {
    @Test
    fun aesRoundTrip() {
        val key = KeyDerivation.deriveNoteKey("4821", "100", ByteArray(16) { it.toByte() })
        val cipher = AesGcmCipher()
        val encrypted = cipher.encrypt("Привіт, secret!", key)
        assertEquals("Привіт, secret!", cipher.decrypt(encrypted, key))
        assertNotEquals("Привіт, secret!", encrypted.payload)
    }

    @Test
    fun masterKeyIsNormalizedForCaesar() {
        assertEquals(7, KeyDerivation.masterId("100"))
        val cipher = CaesarCipher()
        val key = byteArrayOf(KeyDerivation.masterId("100").toByte())
        val encrypted = cipher.encrypt("Hello Привіт", key)
        assertEquals("Hello Привіт", cipher.decrypt(encrypted, key))
    }

    @Test
    fun wrongAesKeyFailsAuthentication() {
        val key = KeyDerivation.deriveNoteKey("4821", "100", ByteArray(16) { it.toByte() })
        val wrong = KeyDerivation.deriveNoteKey("4822", "100", ByteArray(16) { it.toByte() })
        val cipher = AesGcmCipher()
        val encrypted = cipher.encrypt("secret", key)
        var failed = false
        try {
            cipher.decrypt(encrypted, wrong)
        } catch (_: Exception) {
            failed = true
        }
        assertEquals(true, failed)
    }
}
