package com.reed.encryptednotebook.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "notes")
data class NoteEntity(
    @PrimaryKey val id: String,
    val titleCipher: String,
    val titleNonce: String?,
    val bodyCipher: String,
    val bodyNonce: String?,
    val passwordCipher: String,
    val passwordNonce: String?,
    val tagsCipher: String,
    val tagsNonce: String?,
    val createdAt: Long,
    val updatedAt: Long,
    val cipherMode: String
)
