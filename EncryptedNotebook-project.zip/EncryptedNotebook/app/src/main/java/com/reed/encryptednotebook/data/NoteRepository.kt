package com.reed.encryptednotebook.data

import android.util.Base64
import com.reed.encryptednotebook.security.AesGcmCipher
import com.reed.encryptednotebook.security.CaesarCipher
import com.reed.encryptednotebook.security.CipherMethod
import com.reed.encryptednotebook.security.Ciphertext
import com.reed.encryptednotebook.security.KeyDerivation
import com.reed.encryptednotebook.security.CryptoSession
import kotlinx.coroutines.flow.Flow
import java.util.UUID

class NoteRepository(private val db: AppDatabase) {
    private val aes = AesGcmCipher()
    private val caesar = CaesarCipher()

    fun observeAll(): Flow<List<NoteEntity>> = db.noteDao().observeAll()
    suspend fun get(id: String): NoteEntity? = db.noteDao().getById(id)
    suspend fun delete(note: NoteEntity) = db.noteDao().delete(note)

    suspend fun save(
        id: String?,
        title: String,
        body: String,
        tags: String,
        password: String = "",
        mode: String,
        session: CryptoSession,
        now: Long = System.currentTimeMillis()
    ) {
        val cipher = method(mode)
        val encryptedTitle = cipher.encrypt(title, session.keyFor(mode))
        val encryptedBody = cipher.encrypt(body, session.keyFor(mode))
        val encryptedPassword = cipher.encrypt(password, session.keyFor(mode))
        val encryptedTags = cipher.encrypt(tags, session.keyFor(mode))
        val existing = id?.let { db.noteDao().getById(it) }
        val note = NoteEntity(
            id = existing?.id ?: UUID.randomUUID().toString(),
            titleCipher = encryptedTitle.payload,
            titleNonce = encryptedTitle.nonce,
            bodyCipher = encryptedBody.payload,
            bodyNonce = encryptedBody.nonce,
            passwordCipher = encryptedPassword.payload,
            passwordNonce = encryptedPassword.nonce,
            tagsCipher = encryptedTags.payload,
            tagsNonce = encryptedTags.nonce,
            createdAt = existing?.createdAt ?: now,
            updatedAt = now,
            cipherMode = mode
        )
        if (existing == null) db.noteDao().insert(note) else db.noteDao().update(note)
    }

    fun decrypt(note: NoteEntity, session: CryptoSession): DecryptedNote {
        val cipher = method(note.cipherMode)
        return DecryptedNote(
            id = note.id,
            title = cipher.decrypt(Ciphertext(note.titleCipher, note.titleNonce), session.keyFor(note.cipherMode)),
            body = cipher.decrypt(Ciphertext(note.bodyCipher, note.bodyNonce), session.keyFor(note.cipherMode)),
            password = cipher.decrypt(Ciphertext(note.passwordCipher, note.passwordNonce), session.keyFor(note.cipherMode)),
            tags = cipher.decrypt(Ciphertext(note.tagsCipher, note.tagsNonce), session.keyFor(note.cipherMode)),
            createdAt = note.createdAt,
            updatedAt = note.updatedAt
        )
    }

    fun method(mode: String): CipherMethod = if (mode == "CAESAR") caesar else aes

    suspend fun importNote(imported: ImportedNote, session: CryptoSession) {
        save(
            id = null,
            title = imported.title,
            body = imported.body,
            tags = imported.tags,
            password = imported.password,
            mode = "AES_GCM",
            session = session,
            now = imported.updatedAt
        )
    }

    companion object {
        fun exportKey(masterKey: String): ByteArray = KeyDerivation.sha256("ENB-EXPORT-V1|$masterKey")

        fun packExport(notes: List<DecryptedNote>, masterKey: String): String {
            val array = org.json.JSONArray()
            notes.forEach { note ->
                array.put(org.json.JSONObject().apply {
                    put("title", note.title)
                    put("body", note.body)
                    put("password", note.password)
                    put("tags", note.tags)
                    put("createdAt", note.createdAt)
                    put("updatedAt", note.updatedAt)
                })
            }
            val payload = org.json.JSONObject().apply {
                put("format", "ENB1")
                put("notes", array)
            }.toString()
            val cipher = AesGcmCipher().encrypt(payload, exportKey(masterKey))
            val packed = "ENB1|${cipher.nonce}|${cipher.payload}"
            return Base64.encodeToString(packed.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
        }

        fun unpackExport(value: String, masterKey: String): List<ImportedNote> {
            val raw = Base64.decode(value, Base64.NO_WRAP).toString(Charsets.UTF_8)
            val parts = raw.split("|", limit = 3)
            require(parts.size == 3 && parts[0] == "ENB1") { "Invalid export" }
            val plain = AesGcmCipher().decrypt(Ciphertext(parts[2], parts[1]), exportKey(masterKey))
            val root = org.json.JSONObject(plain)
            require(root.optString("format") == "ENB1") { "Invalid payload" }
            val array = root.getJSONArray("notes")
            return buildList {
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    add(
                        ImportedNote(
                            createdAt = obj.optLong("createdAt", System.currentTimeMillis()),
                            updatedAt = obj.optLong("updatedAt", System.currentTimeMillis()),
                            title = obj.optString("title"),
                            body = obj.optString("body"),
                            password = obj.optString("password"),
                            tags = obj.optString("tags")
                        )
                    )
                }
            }
        }
    }

}

data class DecryptedNote(
    val id: String,
    val title: String,
    val body: String,
    val password: String,
    val tags: String,
    val createdAt: Long,
    val updatedAt: Long
)

data class ImportedNote(
    val createdAt: Long,
    val updatedAt: Long,
    val title: String,
    val body: String,
    val password: String,
    val tags: String
)
