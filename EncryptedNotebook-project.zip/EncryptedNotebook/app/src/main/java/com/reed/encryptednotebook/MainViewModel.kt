package com.reed.encryptednotebook

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.reed.encryptednotebook.data.DecryptedNote
import com.reed.encryptednotebook.data.NoteEntity
import com.reed.encryptednotebook.data.NoteRepository
import com.reed.encryptednotebook.security.KeyDerivation
import com.reed.encryptednotebook.security.CryptoSession
import com.reed.encryptednotebook.security.SecurityRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val security: SecurityRepository = (app as NotebookApplication).security
    private val repository: NoteRepository = (app as NotebookApplication).notes

    private val _notes = MutableStateFlow<List<NoteEntity>>(emptyList())
    val notes: StateFlow<List<NoteEntity>> = _notes.asStateFlow()

    private val _state = MutableStateFlow(
        UiState(
            configured = security.isConfigured,
            screen = if (security.isConfigured) Screen.PIN else Screen.ONBOARDING,
            autoLockMinutes = security.autoLockMinutes(),
            biometricEnabled = security.biometricEnabled(),
            language = security.language(),
            cipherMode = security.cipherMode()
        )
    )
    val state: StateFlow<UiState> = _state.asStateFlow()

    private var cryptoSession: CryptoSession? = null
    private var pinForSession: String? = null
    private var masterKeyForSession: String? = null
    private var setupPin: String? = null

    init {
        if (security.isConfigured) observeNotes()
    }

    private fun observeNotes() {
        viewModelScope.launch {
            repository.observeAll().collect { _notes.value = it }
        }
    }

    fun navigate(screen: Screen) {
        _state.value = _state.value.copy(screen = screen)
    }

    fun openEditor(id: String?) {
        _state.value = _state.value.copy(screen = Screen.EDIT_NOTE, editingNoteId = id)
    }

    fun beginSetup() {
        setupPin = null
        _state.value = _state.value.copy(screen = Screen.SETUP_PIN)
    }

    fun setSetupPin(pin: String) {
        setupPin = pin
        _state.value = _state.value.copy(screen = Screen.SETUP_KEY)
    }

    fun finishSetup(masterKey: String) {
        val pin = setupPin ?: return
        security.configure(pin, masterKey)
        pinForSession = null
        masterKeyForSession = null
        cryptoSession?.wipe()
        cryptoSession = null
        _state.value = _state.value.copy(configured = true, screen = Screen.WARNING)
        observeNotes()
    }

    fun pinLockRemaining(): Long = maxOf(0L, security.pinLockUntil() - System.currentTimeMillis())
    fun keyLockRemaining(): Long = maxOf(0L, security.keyLockUntil() - System.currentTimeMillis())

    fun verifyPin(pin: String): PinResult {
        val now = System.currentTimeMillis()
        if (security.pinLockUntil() > now) return PinResult.Locked(security.pinLockUntil())
        return if (security.verifyPin(pin)) {
            security.clearPinFailures()
            pinForSession = pin
            _state.value = _state.value.copy(screen = Screen.LOCKED_NOTES, pinError = null)
            PinResult.Success
        } else {
            val failures = security.recordPinFailure()
            if (security.pinLockUntil() > System.currentTimeMillis()) PinResult.Locked(security.pinLockUntil())
            else PinResult.Wrong(failures)
        }
    }

    fun unlockWithBiometric() {
        val pin = security.storedPinForBiometric() ?: return
        pinForSession = pin
        _state.value = _state.value.copy(screen = Screen.LOCKED_NOTES, pinError = null)
    }

    fun verifyMasterKey(masterKey: String): KeyResult {
        val now = System.currentTimeMillis()
        if (security.keyLockUntil() > now) return KeyResult.Locked(security.keyLockUntil())
        val pin = pinForSession ?: return KeyResult.Wrong(0)
        val salt = security.noteSalt() ?: return KeyResult.Wrong(0)
        val storedMaster = security.masterKey() ?: return KeyResult.Wrong(0)
        val candidate = KeyDerivation.deriveNoteKey(pin, masterKey, salt)
        val valid = KeyDerivation.constantTimeEquals(
            KeyDerivation.sha256("MASTER|$masterKey"),
            KeyDerivation.sha256("MASTER|$storedMaster")
        )
        if (!valid) {
            val failures = security.recordKeyFailure()
            if (security.keyLockUntil() > System.currentTimeMillis()) return KeyResult.Locked(security.keyLockUntil())
            return KeyResult.Wrong(failures)
        }
        cryptoSession = CryptoSession(candidate, byteArrayOf(KeyDerivation.masterId(masterKey).toByte()))
        masterKeyForSession = masterKey
        security.clearKeyFailures()
        _state.value = _state.value.copy(screen = Screen.NOTES, keyError = null, unlocked = true)
        return KeyResult.Success
    }

    fun lock() {
        cryptoSession?.wipe()
        cryptoSession = null
        pinForSession = null
        masterKeyForSession = null
        _state.value = _state.value.copy(screen = Screen.PIN, unlocked = false, editingNoteId = null)
    }

    fun createOrUpdateNote(id: String?, title: String, body: String, password: String, tags: String) {
        val session = cryptoSession ?: return
        viewModelScope.launch { repository.save(id, title, body, tags, password, _state.value.cipherMode, session) }
    }

    fun deleteNote(note: NoteEntity) { viewModelScope.launch { repository.delete(note) } }

    suspend fun decrypt(note: NoteEntity): DecryptedNote? = cryptoSession?.let { repository.decrypt(note, it) }

    suspend fun export(note: NoteEntity): String? {
        val session = cryptoSession ?: return null
        val master = masterKeyForSession ?: return null
        return NoteRepository.packExport(listOf(repository.decrypt(note, session)), master)
    }

    suspend fun exportAll(): String? {
        val session = cryptoSession ?: return null
        val master = masterKeyForSession ?: return null
        val decrypted = _notes.value.mapNotNull { runCatching { repository.decrypt(it, session) }.getOrNull() }
        return NoteRepository.packExport(decrypted, master)
    }

    fun importText(text: String): Result<Unit> {
        val session = cryptoSession ?: return Result.failure(IllegalStateException("Locked"))
        val master = masterKeyForSession ?: return Result.failure(IllegalStateException("Locked"))
        return try {
            val imported = NoteRepository.unpackExport(text.trim(), master)
            viewModelScope.launch { imported.forEach { repository.importNote(it, session) } }
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun setAutoLock(minutes: Int) {
        security.setAutoLockMinutes(minutes)
        _state.value = _state.value.copy(autoLockMinutes = minutes)
    }

    fun setBiometric(enabled: Boolean) {
        security.setBiometric(enabled)
        _state.value = _state.value.copy(biometricEnabled = enabled)
    }

    fun setLanguage(language: String) {
        security.setLanguage(language)
        _state.value = _state.value.copy(language = language)
    }

    fun setCipherMode(mode: String) {
        security.setCipherMode(mode)
        _state.value = _state.value.copy(cipherMode = mode)
    }

    fun verifyCurrentCredentials(pin: String, masterKey: String): Boolean =
        security.verifyPin(pin) && security.masterKey() == masterKey

    fun changePin(newPin: String) {
        val oldSession = cryptoSession ?: return
        val oldSessionCopy = CryptoSession(oldSession.aesKey.copyOf(), oldSession.caesarKey.copyOf())
        val master = masterKeyForSession ?: return
        viewModelScope.launch {
            val notes = _notes.value.toList()
            security.changePin(newPin)
            val salt = security.noteSalt() ?: return@launch
            val newSession = CryptoSession(
                KeyDerivation.deriveNoteKey(newPin, master, salt),
                byteArrayOf(KeyDerivation.masterId(master).toByte())
            )
            notes.forEach { note ->
                val plain = runCatching { repository.decrypt(note, oldSessionCopy) }.getOrNull() ?: return@forEach
                repository.save(note.id, plain.title, plain.body, plain.tags, plain.password, note.cipherMode, newSession)
            }
            oldSessionCopy.wipe()
            cryptoSession?.wipe()
            cryptoSession = newSession
            pinForSession = newPin
        }
    }

    override fun onCleared() {
        cryptoSession?.wipe()
        cryptoSession = null
        super.onCleared()
    }
}

enum class Screen { ONBOARDING, SETUP_PIN, SETUP_KEY, WARNING, PIN, LOCKED_NOTES, MASTER_KEY, NOTES, EDIT_NOTE, SETTINGS, HELP, EXPORT, IMPORT }

data class UiState(
    val configured: Boolean,
    val screen: Screen,
    val unlocked: Boolean = false,
    val pinError: String? = null,
    val keyError: String? = null,
    val autoLockMinutes: Int = 1,
    val biometricEnabled: Boolean = false,
    val language: String = "uk",
    val cipherMode: String = "AES_GCM",
    val editingNoteId: String? = null
)

sealed interface PinResult {
    data object Success : PinResult
    data class Wrong(val failures: Int) : PinResult
    data class Locked(val until: Long) : PinResult
}

sealed interface KeyResult {
    data object Success : KeyResult
    data class Wrong(val failures: Int) : KeyResult
    data class Locked(val until: Long) : KeyResult
}
