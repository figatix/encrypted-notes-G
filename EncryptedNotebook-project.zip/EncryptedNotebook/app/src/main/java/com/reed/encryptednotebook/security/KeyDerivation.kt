package com.reed.encryptednotebook.security

import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

object KeyDerivation {
    private const val ITERATIONS = 600_000
    private const val KEY_BITS = 256

    fun randomSalt(size: Int = 16): ByteArray = ByteArray(size).also { SecureRandom().nextBytes(it) }

    fun deriveNoteKey(pin: String, masterKey: String, salt: ByteArray): ByteArray {
        val material = "ENB|$pin|$masterKey".toCharArray()
        val spec = PBEKeySpec(material, salt, ITERATIONS, KEY_BITS)
        return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
    }

    fun sha256(value: String): ByteArray = MessageDigest.getInstance("SHA-256").digest(value.toByteArray(Charsets.UTF_8))

    fun constantTimeEquals(a: ByteArray, b: ByteArray): Boolean = MessageDigest.isEqual(a, b)

    fun masterId(masterKey: String): Int {
        val value = masterKey.toLongOrNull() ?: return 0
        return Math.floorMod(value, 31L).toInt()
    }
}
