package com.reed.encryptednotebook.security

import android.content.Context
import android.os.SystemClock
import java.util.UUID

class SecurityRepository(context: Context) {
    private val secure = KeystoreStore(context)

    var isConfigured: Boolean
        get() = secure.get(KEY_CONFIGURED) == "true"
        private set(value) = secure.put(KEY_CONFIGURED, value.toString())

    fun configure(pin: String, masterKey: String) {
        val salt = KeyDerivation.randomSalt()
        val pinHash = KeyDerivation.sha256("PIN|$pin|${Base64Url.encode(salt)}")
        secure.put(KEY_PIN_HASH, Base64Url.encode(pinHash))
        secure.put(KEY_PIN_SALT, Base64Url.encode(salt))
        secure.put(KEY_MASTER_KEY, masterKey)
        secure.put(KEY_PIN_VALUE, pin)
        secure.put(KEY_NOTE_SALT, Base64Url.encode(KeyDerivation.randomSalt()))
        secure.put(KEY_MASTER_ID, KeyDerivation.masterId(masterKey).toString())
        secure.put(KEY_LOCK_PIN_UNTIL, "0")
        secure.put(KEY_LOCK_KEY_UNTIL, "0")
        secure.put(KEY_PIN_FAILURES, "0")
        secure.put(KEY_KEY_FAILURES, "0")
        secure.put(KEY_CONFIGURED, "true")
    }

    fun verifyPin(pin: String): Boolean {
        val salt = secure.get(KEY_PIN_SALT)?.let(Base64Url::decode) ?: return false
        val expected = secure.get(KEY_PIN_HASH)?.let(Base64Url::decode) ?: return false
        val actual = KeyDerivation.sha256("PIN|$pin|${Base64Url.encode(salt)}")
        return KeyDerivation.constantTimeEquals(actual, expected)
    }

    fun masterKey(): String? = secure.get(KEY_MASTER_KEY)
    fun storedPinForBiometric(): String? = secure.get(KEY_PIN_VALUE)
    fun noteSalt(): ByteArray? = secure.get(KEY_NOTE_SALT)?.let(Base64Url::decode)
    fun masterId(): Int = secure.get(KEY_MASTER_ID)?.toIntOrNull() ?: 0

    fun pinFailures(): Int = secure.get(KEY_PIN_FAILURES)?.toIntOrNull() ?: 0
    fun keyFailures(): Int = secure.get(KEY_KEY_FAILURES)?.toIntOrNull() ?: 0
    fun pinLockUntil(): Long = secure.get(KEY_LOCK_PIN_UNTIL)?.toLongOrNull() ?: 0L
    fun keyLockUntil(): Long = secure.get(KEY_LOCK_KEY_UNTIL)?.toLongOrNull() ?: 0L

    fun recordPinFailure(): Int {
        val next = pinFailures() + 1
        if (next >= 5) {
            secure.put(KEY_LOCK_PIN_UNTIL, (System.currentTimeMillis() + TEN_MINUTES).toString())
            secure.put(KEY_PIN_FAILURES, "0")
        } else secure.put(KEY_PIN_FAILURES, next.toString())
        return next
    }

    fun recordKeyFailure(): Int {
        val next = keyFailures() + 1
        if (next >= 5) {
            secure.put(KEY_LOCK_KEY_UNTIL, (System.currentTimeMillis() + TEN_MINUTES).toString())
            secure.put(KEY_KEY_FAILURES, "0")
        } else secure.put(KEY_KEY_FAILURES, next.toString())
        return next
    }

    fun clearPinFailures() = secure.put(KEY_PIN_FAILURES, "0")
    fun clearKeyFailures() = secure.put(KEY_KEY_FAILURES, "0")

    fun changePin(newPin: String) {
        val salt = KeyDerivation.randomSalt()
        val pinHash = KeyDerivation.sha256("PIN|$newPin|${Base64Url.encode(salt)}")
        secure.put(KEY_PIN_HASH, Base64Url.encode(pinHash))
        secure.put(KEY_PIN_SALT, Base64Url.encode(salt))
        secure.put(KEY_PIN_VALUE, newPin)
    }

    fun setAutoLockMinutes(minutes: Int) = secure.put(KEY_AUTO_LOCK, minutes.toString())
    fun autoLockMinutes(): Int = secure.get(KEY_AUTO_LOCK)?.toIntOrNull() ?: 1

    fun setBiometric(enabled: Boolean) = secure.put(KEY_BIOMETRIC, enabled.toString())
    fun biometricEnabled(): Boolean = secure.get(KEY_BIOMETRIC) == "true"

    fun setLanguage(language: String) = secure.put(KEY_LANGUAGE, language)
    fun language(): String = secure.get(KEY_LANGUAGE) ?: "uk"

    fun setCipherMode(mode: String) = secure.put(KEY_CIPHER_MODE, mode)
    fun cipherMode(): String = secure.get(KEY_CIPHER_MODE) ?: "AES_GCM"

    companion object {
        private const val KEY_CONFIGURED = "configured"
        private const val KEY_PIN_HASH = "pin_hash"
        private const val KEY_PIN_SALT = "pin_salt"
        private const val KEY_MASTER_KEY = "master_key"
        private const val KEY_PIN_VALUE = "pin_value_keystore_encrypted"
        private const val KEY_MASTER_ID = "master_id"
        private const val KEY_NOTE_SALT = "note_salt"
        private const val KEY_LOCK_PIN_UNTIL = "pin_lock_until"
        private const val KEY_LOCK_KEY_UNTIL = "key_lock_until"
        private const val KEY_PIN_FAILURES = "pin_failures"
        private const val KEY_KEY_FAILURES = "key_failures"
        private const val KEY_AUTO_LOCK = "auto_lock"
        private const val KEY_BIOMETRIC = "biometric"
        private const val KEY_LANGUAGE = "language"
        private const val KEY_CIPHER_MODE = "cipher_mode"
        private const val TEN_MINUTES = 10 * 60 * 1000L
    }
}

object Base64Url {
    fun encode(bytes: ByteArray): String = Base64.encodeToString(bytes, Base64.NO_WRAP or Base64.URL_SAFE)
    fun decode(value: String): ByteArray = Base64.decode(value, Base64.NO_WRAP or Base64.URL_SAFE)
}
