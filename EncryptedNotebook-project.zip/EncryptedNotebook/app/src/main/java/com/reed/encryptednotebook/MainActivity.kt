package com.reed.encryptednotebook

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import com.reed.encryptednotebook.data.DecryptedNote
import com.reed.encryptednotebook.data.NoteEntity
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import androidx.compose.runtime.rememberCoroutineScope
import java.security.SecureRandom

class MainActivity : ComponentActivity() {
    private lateinit var viewModel: MainViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        viewModel = ViewModelProvider(this)[MainViewModel::class.java]
        setContent { EncryptedNotebookApp(viewModel) }
    }

    fun biometricAvailable(): Boolean =
        BiometricManager.from(this).canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_WEAK) == BiometricManager.BIOMETRIC_SUCCESS

    fun launchBiometric(onSuccess: () -> Unit) {
        if (!biometricAvailable()) return
        val prompt = BiometricPrompt(
            this,
            mainExecutor,
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    onSuccess()
                }
            }
        )
        prompt.authenticate(
            BiometricPrompt.PromptInfo.Builder()
                .setTitle("Encrypted Notebook")
                .setSubtitle("Підтвердьте особу, щоб увійти")
                .setNegativeButtonText("Скасувати")
                .build()
        )
    }
}

@Composable
fun EncryptedNotebookApp(vm: MainViewModel) {
    val state by vm.state.collectAsState()
    val context = LocalContext.current
    var lastInteraction by remember { mutableStateOf(System.currentTimeMillis()) }
    fun touch() { lastInteraction = System.currentTimeMillis() }

    LaunchedEffect(state.unlocked, state.autoLockMinutes) {
        while (state.unlocked) {
            delay(5_000)
            if (System.currentTimeMillis() - lastInteraction >= state.autoLockMinutes * 60_000L) {
                vm.lock()
                break
            }
        }
    }

    MaterialTheme {
        when (state.screen) {
            Screen.ONBOARDING -> OnboardingScreen(state.language) { vm.setLanguage(it); vm.beginSetup() }
            Screen.SETUP_PIN -> SetupPinScreen(vm, state)
            Screen.SETUP_KEY -> SetupKeyScreen(vm, state)
            Screen.WARNING -> WarningScreen(state.language == "uk") { vm.navigate(Screen.PIN) }
            Screen.PIN -> PinScreen(vm, state, context as? MainActivity)
            Screen.LOCKED_NOTES -> LockedNotesScreen(vm, state)
            Screen.MASTER_KEY -> MasterKeyScreen(vm, state)
            Screen.NOTES -> NotesScreen(vm, state, { touch() })
            Screen.EDIT_NOTE -> NoteEditorScreen(vm, state, { touch() })
            Screen.SETTINGS -> SettingsScreen(vm, state)
            Screen.HELP -> HelpScreen(state.language) { vm.navigate(if (state.unlocked) Screen.NOTES else Screen.PIN) }
            Screen.EXPORT -> ExportScreen(vm, state) { vm.navigate(Screen.NOTES) }
            Screen.IMPORT -> ImportScreen(vm, state) { vm.navigate(Screen.NOTES) }
        }
    }
}

@Composable
private fun OnboardingScreen(language: String, onStart: (String) -> Unit) {
    var page by rememberSaveable { mutableIntStateOf(0) }
    var selectedLanguage by rememberSaveable { mutableStateOf(language) }
    val uk = selectedLanguage == "uk"
    val pages = if (uk) listOf(
        "Що це" to "Офлайн-блокнот для логінів, паролів, кодів та приватних нотаток. Інтернет не потрібен.",
        "PIN і ключ" to "PIN відкриває застосунок. Головний ключ відкриває справжній текст нотаток. Це два різні секрети.",
        "Не забудьте" to "Якщо забудете PIN або головний ключ, відновити нотатки неможливо. Це свідомий компроміс на користь безпеки.",
        "Перенесення" to "Нотатки можна експортувати в один зашифрований Base64-рядок і імпортувати на іншому пристрої з тим самим головним ключем."
    ) else listOf(
        "What is it" to "An offline notebook for logins, passwords, codes and private notes. No internet is required.",
        "PIN and key" to "The PIN opens the app. The master key unlocks the real note text. They are two different secrets.",
        "Do not forget" to "If you forget the PIN or master key, the notes cannot be recovered. This is intentional for security.",
        "Transfer" to "Export notes as one encrypted Base64 string and import them on another device with the same master key."
    )
    Scaffold { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(24.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
            Text("🔐", style = MaterialTheme.typography.displayLarge)
            Spacer(Modifier.height(24.dp))
            Text(pages[page].first, style = MaterialTheme.typography.headlineMedium)
            Spacer(Modifier.height(12.dp))
            Text(pages[page].second, style = MaterialTheme.typography.bodyLarge)
            Spacer(Modifier.height(28.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { repeat(pages.size) { i -> Text(if (i == page) "●" else "○") } }
            Spacer(Modifier.height(24.dp))
            Button(onClick = { if (page < pages.lastIndex) page++ else onStart(selectedLanguage) }) { Text(if (page < pages.lastIndex) if (uk) "Далі" else "Next" else if (uk) "Почати" else "Start") }
            Spacer(Modifier.height(10.dp))
            TextButton(onClick = { selectedLanguage = if (selectedLanguage == "uk") "en" else "uk" }) { Text(if (uk) "English" else "Українська") }
        }
    }
}

@Composable
private fun SetupPinScreen(vm: MainViewModel, state: UiState) {
    val uk = state.language == "uk"
    var pin by rememberSaveable { mutableStateOf("") }
    var confirm by rememberSaveable { mutableStateOf("") }
    Scaffold { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(24.dp), verticalArrangement = Arrangement.Center) {
            Text(if (uk) "Створіть PIN" else "Create a PIN", style = MaterialTheme.typography.headlineMedium)
            Spacer(Modifier.height(10.dp))
            Text(if (uk) "4–6 цифр. PIN потрібен для входу в застосунок." else "4–6 digits. The PIN is used to enter the app.")
            Spacer(Modifier.height(20.dp))
            OutlinedTextField(pin, { if (it.all(Char::isDigit) && it.length <= 6) pin = it }, label = { Text("PIN") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(confirm, { if (it.all(Char::isDigit) && it.length <= 6) confirm = it }, label = { Text(if (uk) "Підтвердіть PIN" else "Confirm PIN") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(18.dp))
            Button(onClick = { vm.setSetupPin(pin) }, enabled = pin.length in 4..6 && pin == confirm, modifier = Modifier.fillMaxWidth()) { Text(if (uk) "Далі" else "Next") }
        }
    }
}

@Composable
private fun SetupKeyScreen(vm: MainViewModel, state: UiState) {
    val uk = state.language == "uk"
    var key by rememberSaveable { mutableStateOf("") }
    Scaffold { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(24.dp), verticalArrangement = Arrangement.Center) {
            Text(if (uk) "Створіть головний ключ" else "Create the master key", style = MaterialTheme.typography.headlineMedium)
            Spacer(Modifier.height(10.dp))
            Text(if (uk) "Довільне ціле число, наприклад 100. Не використовуйте PIN повторно." else "Any integer, for example 100. Do not reuse your PIN.")
            Spacer(Modifier.height(20.dp))
            OutlinedTextField(key, { if (it.length <= 18 && (it.isEmpty() || it.matches(Regex("-?\\d+")))) key = it }, label = { Text(if (uk) "Головний ключ" else "Master key") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(18.dp))
            Button(onClick = { vm.finishSetup(key) }, enabled = key.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text(if (uk) "Створити блокнот" else "Create notebook") }
        }
    }
}

@Composable
private fun WarningScreen(uk: Boolean, onContinue: () -> Unit) {
    Scaffold { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(24.dp), verticalArrangement = Arrangement.Center) {
            Text("⚠️", style = MaterialTheme.typography.displayMedium)
            Spacer(Modifier.height(16.dp))
            Text(if (uk) "Якщо ви забудете PIN або ключ, відновити нотатки буде неможливо." else "If you forget the PIN or key, the notes cannot be recovered.", style = MaterialTheme.typography.headlineSmall)
            Spacer(Modifier.height(24.dp))
            Button(onClick = onContinue, modifier = Modifier.fillMaxWidth()) { Text(if (uk) "Я розумію" else "I understand") }
        }
    }
}

@Composable
private fun PinScreen(vm: MainViewModel, state: UiState, activity: MainActivity?) {
    var pin by rememberSaveable { mutableStateOf("") }
    var error by rememberSaveable { mutableStateOf<String?>(null) }
    var remaining by remember { mutableStateOf(0L) }
    val uk = state.language == "uk"
    LaunchedEffect(Unit) {
        while (true) {
            remaining = vm.pinLockRemaining()
            delay(1000)
        }
    }
    val locked = remaining > 0
    Scaffold { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(24.dp), verticalArrangement = Arrangement.Center) {
            Text("🔐", style = MaterialTheme.typography.displayMedium, modifier = Modifier.align(Alignment.CenterHorizontally))
            Spacer(Modifier.height(12.dp))
            Text(if (uk) "Введіть PIN" else "Enter PIN", style = MaterialTheme.typography.headlineMedium)
            Spacer(Modifier.height(8.dp))
            Text(if (uk) "PIN відкриває застосунок. Потім буде потрібен головний ключ." else "The PIN opens the app. Then the master key is required.")
            Spacer(Modifier.height(20.dp))
            OutlinedTextField(pin, { if (it.all(Char::isDigit) && it.length <= 6) pin = it }, label = { Text("PIN") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), enabled = !locked, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(12.dp))
            Button(onClick = {
                when (val result = vm.verifyPin(pin)) {
                    PinResult.Success -> error = null
                    is PinResult.Wrong -> error = if (uk) "Невірний PIN. Залишилось спроб: ${5 - result.failures}" else "Wrong PIN. Attempts left: ${5 - result.failures}"
                    is PinResult.Locked -> error = if (uk) "PIN заблоковано на 10 хвилин." else "PIN locked for 10 minutes."
                }
            }, enabled = pin.length in 4..6 && !locked, modifier = Modifier.fillMaxWidth()) { Text(if (uk) "Увійти" else "Sign in") }
            if (state.biometricEnabled && activity?.biometricAvailable() == true) {
                Spacer(Modifier.height(10.dp))
                OutlinedButton(onClick = { activity.launchBiometric { vm.unlockWithBiometric() } }, enabled = !locked, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.Fingerprint, null); Spacer(Modifier.width(8.dp)); Text(if (uk) "Увійти біометрією" else "Use biometrics")
                }
            }
            if (locked) { Spacer(Modifier.height(12.dp)); Text(if (uk) "Спробуйте через ${remaining / 1000}s" else "Try again in ${remaining / 1000}s") }
            error?.let { Spacer(Modifier.height(10.dp)); Text(it, color = MaterialTheme.colorScheme.error) }
        }
    }
}

@Composable
private fun LockedNotesScreen(vm: MainViewModel, state: UiState) {
    val uk = state.language == "uk"
    val notes by vm.notes.collectAsState()
    Scaffold(topBar = {
        CenterAlignedTopAppBar(
            title = { Text(if (uk) "Нотатки заблоковані" else "Notes locked") },
            actions = { IconButton(onClick = { vm.lock() }) { Icon(Icons.Default.Lock, null) } }
        )
    }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(12.dp)) {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)) {
                Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.HelpOutline, null)
                    Spacer(Modifier.width(8.dp))
                    Text(if (uk) "PIN пройдено. Текст нотаток поки не розшифрований. Введіть головний ключ, щоб прочитати їх." else "PIN accepted. Note text is still encrypted. Enter the master key to read it.")
                }
            }
            Spacer(Modifier.height(10.dp))
            if (notes.isEmpty()) {
                Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                    Text(if (uk) "Нотаток ще немає." else "There are no notes yet.")
                }
            } else {
                LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(notes, key = { it.id }) { note ->
                        Card(shape = RoundedCornerShape(18.dp)) {
                            Column(Modifier.fillMaxWidth().padding(16.dp)) {
                                Text(note.titleCipher, style = MaterialTheme.typography.titleSmall, maxLines = 2)
                                Spacer(Modifier.height(6.dp))
                                Text(note.bodyCipher, maxLines = 3)
                            }
                        }
                    }
                }
            }
            Button(onClick = { vm.navigate(Screen.MASTER_KEY) }, modifier = Modifier.fillMaxWidth()) {
                Text(if (uk) "Ввести головний ключ" else "Enter master key")
            }
        }
    }
}

@Composable
private fun MasterKeyScreen(vm: MainViewModel, state: UiState) {
    var key by rememberSaveable { mutableStateOf("") }
    var error by rememberSaveable { mutableStateOf<String?>(null) }
    var remaining by remember { mutableStateOf(0L) }
    val uk = state.language == "uk"
    LaunchedEffect(Unit) {
        while (true) { remaining = vm.keyLockRemaining(); delay(1000) }
    }
    val locked = remaining > 0
    Scaffold { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(24.dp), verticalArrangement = Arrangement.Center) {
            Text("🗝️", style = MaterialTheme.typography.displayMedium)
            Spacer(Modifier.height(10.dp))
            Text(if (uk) "Головний ключ" else "Master key", style = MaterialTheme.typography.headlineMedium)
            Spacer(Modifier.height(8.dp))
            Text(if (uk) "Введіть ключ, щоб побачити справжній текст нотаток." else "Enter the key to see the real note text.")
            Spacer(Modifier.height(20.dp))
            OutlinedTextField(key, { key = it }, label = { Text(if (uk) "Ключ" else "Key") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), enabled = !locked, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(12.dp))
            Button(onClick = {
                when (val result = vm.verifyMasterKey(key)) {
                    KeyResult.Success -> error = null
                    is KeyResult.Wrong -> error = if (uk) "Невірний ключ. Залишилось спроб: ${5 - result.failures}" else "Wrong key. Attempts left: ${5 - result.failures}"
                    is KeyResult.Locked -> error = if (uk) "Ключ заблоковано на 10 хвилин." else "Key locked for 10 minutes."
                }
            }, enabled = key.isNotBlank() && !locked, modifier = Modifier.fillMaxWidth()) { Text(if (uk) "Розблокувати" else "Unlock") }
            if (locked) { Spacer(Modifier.height(10.dp)); Text(if (uk) "Спробуйте через ${remaining / 1000}s" else "Try again in ${remaining / 1000}s") }
            error?.let { Spacer(Modifier.height(10.dp)); Text(it, color = MaterialTheme.colorScheme.error) }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun NotesScreen(vm: MainViewModel, state: UiState, touch: () -> Unit) {
    val uk = state.language == "uk"
    val notes by vm.notes.collectAsState()
    var query by rememberSaveable { mutableStateOf("") }
    var menu by remember { mutableStateOf(false) }
    var decrypted by remember { mutableStateOf<Map<String, DecryptedNote>>(emptyMap()) }
    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    val context = LocalContext.current

    LaunchedEffect(notes, state.unlocked) {
        decrypted = buildMap {
            notes.forEach { note -> runCatching { vm.decrypt(note) }.getOrNull()?.let { put(note.id, it) } }
        }
    }
    val filtered = notes.filter { note ->
        val d = decrypted[note.id]
        query.isBlank() || d?.title?.contains(query, true) == true || d?.body?.contains(query, true) == true || d?.tags?.contains(query, true) == true
    }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text(if (uk) "Шифрований блокнот" else "Encrypted Notebook") },
                actions = {
                    IconButton(onClick = { vm.lock(); touch() }) { Icon(Icons.Default.Lock, null) }
                    IconButton(onClick = { vm.navigate(Screen.SETTINGS); touch() }) { Icon(Icons.Default.Settings, null) }
                    Box {
                        IconButton(onClick = { menu = true }) { Icon(Icons.Default.MoreVert, null) }
                        DropdownMenu(menu, { menu = false }) {
                            DropdownMenuItem(text = { Text(if (uk) "Імпорт" else "Import") }, onClick = { menu = false; vm.navigate(Screen.IMPORT) })
                            DropdownMenuItem(text = { Text(if (uk) "Довідка" else "Help") }, onClick = { menu = false; vm.navigate(Screen.HELP) })
                        }
                    }
                }
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(onClick = { vm.openEditor(null); touch() }, icon = { Icon(Icons.Default.Add, null) }, text = { Text(if (uk) "Нова" else "New") })
        },
        snackbarHost = { SnackbarHost(snackbar) }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 12.dp)) {
            OutlinedTextField(query, { query = it; touch() }, leadingIcon = { Icon(Icons.Default.Search, null) }, label = { Text(if (uk) "Пошук" else "Search") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp))
            if (filtered.isEmpty()) {
                Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                    Text(if (uk) "Немає нотаток" else "No notes", style = MaterialTheme.typography.titleLarge)
                    Spacer(Modifier.height(8.dp))
                    Text(if (uk) "Натисніть +, щоб створити першу нотатку." else "Press + to create your first note.")
                }
            } else {
                LazyColumn(contentPadding = PaddingValues(bottom = 100.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(filtered, key = { it.id }) { note ->
                        val d = decrypted[note.id]
                        Card(onClick = { vm.openEditor(note.id); touch() }, shape = RoundedCornerShape(18.dp)) {
                            Column(Modifier.fillMaxWidth().padding(16.dp)) {
                                Text(d?.title ?: "••••••••", style = MaterialTheme.typography.titleMedium)
                                Spacer(Modifier.height(5.dp))
                                Text(d?.body?.replace("\n", " ")?.take(100) ?: "••••••••••••", maxLines = 2)
                                if (!d?.tags.isNullOrBlank()) { Spacer(Modifier.height(5.dp)); Text("#${d?.tags}", style = MaterialTheme.typography.labelMedium) }
                                Spacer(Modifier.height(6.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    IconButton(onClick = { vm.deleteNote(note); scope.launch { snackbar.showSnackbar(if (uk) "Нотатку видалено" else "Note deleted") } }) { Icon(Icons.Default.Delete, null) }
                                    IconButton(onClick = { vm.openEditor(note.id) }) { Icon(Icons.Default.Edit, null) }
                                    IconButton(onClick = { scope.launch { vm.export(note)?.let { copyToClipboard(context, it) }; snackbar.showSnackbar(if (uk) "Експорт скопійовано" else "Export copied") } }) { Icon(Icons.Default.ContentCopy, null) }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun NoteEditorScreen(vm: MainViewModel, state: UiState, touch: () -> Unit) {
    val uk = state.language == "uk"
    val context = LocalContext.current
    var title by rememberSaveable(state.editingNoteId) { mutableStateOf("") }
    var body by rememberSaveable(state.editingNoteId) { mutableStateOf("") }
    var tags by rememberSaveable(state.editingNoteId) { mutableStateOf("") }
    var password by rememberSaveable(state.editingNoteId) { mutableStateOf("") }
    var loaded by remember(state.editingNoteId) { mutableStateOf(false) }
    var showGenerator by remember { mutableStateOf(false) }
    var showHint by rememberSaveable { mutableStateOf(true) }

    LaunchedEffect(state.editingNoteId) {
        loaded = false
        if (state.editingNoteId != null) {
            val note = vm.notes.value.firstOrNull { it.id == state.editingNoteId }
            val d = note?.let { vm.decrypt(it) }
            if (d != null) {
                title = d.title
                body = d.body
                tags = d.tags
                password = d.password
            }
        }
        loaded = true
    }

    Scaffold(topBar = {
        CenterAlignedTopAppBar(
            title = { Text(if (uk) "Нотатка" else "Note") },
            navigationIcon = { IconButton(onClick = { vm.navigate(Screen.NOTES) }) { Icon(Icons.Default.ArrowBack, null) } },
            actions = { TextButton(onClick = { vm.createOrUpdateNote(state.editingNoteId, title, body, password, tags); vm.navigate(Screen.NOTES) }) { Text(if (uk) "Зберегти" else "Save") } }
        )
    }) { padding ->
        if (loaded) {
            Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
                if (showHint) {
                    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)) {
                        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.HelpOutline, null); Spacer(Modifier.width(8.dp))
                            Text(if (uk) "Введіть ключ, щоб побачити справжній текст. Без ключа буде видно зашифровані символи." else "Enter the key to see the real text. Without it, encrypted characters are shown.", modifier = Modifier.weight(1f))
                            TextButton(onClick = { showHint = false }) { Text("OK") }
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                }
                OutlinedTextField(title, { title = it; touch() }, label = { Text(if (uk) "Заголовок" else "Title") }, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(body, { body = it; touch() }, label = { Text(if (uk) "Текст нотатки" else "Note text") }, minLines = 8, modifier = Modifier.weight(1f).fillMaxWidth())
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(password, { password = it; touch() }, label = { Text(if (uk) "Пароль (необов'язково)" else "Password (optional)") }, modifier = Modifier.fillMaxWidth(), trailingIcon = { IconButton(onClick = { showGenerator = true }) { Text("⚙") } })
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(tags, { tags = it; touch() }, label = { Text(if (uk) "Теги" else "Tags") }, modifier = Modifier.fillMaxWidth())
                if (password.isNotBlank()) {
                    Spacer(Modifier.height(8.dp))
                    OutlinedButton(onClick = { copyToClipboard(context, password) }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.ContentCopy, null); Spacer(Modifier.width(8.dp)); Text(if (uk) "Копіювати пароль (очиститься через 30 с)" else "Copy password (clears in 30 s)") }
                }
            }
        }
    }
    if (showGenerator) PasswordGeneratorDialog(uk, { password = it; showGenerator = false }, { showGenerator = false })
}


@Composable
private fun PasswordGeneratorDialog(uk: Boolean, onUse: (String) -> Unit, onDismiss: () -> Unit) {
    var length by remember { mutableIntStateOf(16) }
    var upper by remember { mutableStateOf(true) }
    var lower by remember { mutableStateOf(true) }
    var digits by remember { mutableStateOf(true) }
    var symbols by remember { mutableStateOf(true) }
    var generated by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text(if (uk) "Генератор пароля" else "Password generator") }, text = {
        Column {
            Text(if (uk) "Довжина: $length" else "Length: $length")
            Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(upper, { upper = it }); Text("A–Z") }
            Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(lower, { lower = it }); Text("a–z") }
            Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(digits, { digits = it }); Text("0–9") }
            Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(symbols, { symbols = it }); Text(if (uk) "Символи" else "Symbols") }
            Button(onClick = { generated = generatePassword(length, upper, lower, digits, symbols) }) { Text(if (uk) "Згенерувати" else "Generate") }
            if (generated.isNotBlank()) { Spacer(Modifier.height(8.dp)); Text(generated) }
        }
    }, confirmButton = { TextButton(onClick = { if (generated.isNotBlank()) onUse(generated) }) { Text(if (uk) "Використати" else "Use") } }, dismissButton = { TextButton(onClick = onDismiss) { Text(if (uk) "Скасувати" else "Cancel") } })
}

private fun generatePassword(length: Int, upper: Boolean, lower: Boolean, digits: Boolean, symbols: Boolean): String {
    val groups = buildList {
        if (upper) add("ABCDEFGHIJKLMNOPQRSTUVWXYZ")
        if (lower) add("abcdefghijklmnopqrstuvwxyz")
        if (digits) add("0123456789")
        if (symbols) add("!@#$%^&*()-_=+[]{}:;,.?/")
    }
    if (groups.isEmpty()) return ""
    val random = SecureRandom()
    val chars = mutableListOf<Char>()
    groups.forEach { chars += it[random.nextInt(it.length)] }
    val all = groups.joinToString("")
    while (chars.size < length.coerceIn(8, 64)) chars += all[random.nextInt(all.length)]
    chars.shuffle(random)
    return chars.joinToString("")
}

@Composable
private fun SettingsScreen(vm: MainViewModel, state: UiState) {
    val uk = state.language == "uk"
    val context = LocalContext.current
    var showChangePin by remember { mutableStateOf(false) }
    var currentPin by remember { mutableStateOf("") }
    var masterKey by remember { mutableStateOf("") }
    var newPin by remember { mutableStateOf("") }
    Scaffold(topBar = { CenterAlignedTopAppBar(title = { Text(if (uk) "Налаштування" else "Settings") }, navigationIcon = { IconButton(onClick = { vm.navigate(Screen.NOTES) }) { Icon(Icons.Default.ArrowBack, null) } }) }) { padding ->
        LazyColumn(Modifier.fillMaxSize().padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            item {
                Text(if (uk) "Режим шифрування" else "Encryption mode", style = MaterialTheme.typography.titleLarge)
                Text(if (state.cipherMode == "AES_GCM") "Надійний (AES-256-GCM)" else "Простий зсув (Цезар)")
                Text(if (state.cipherMode == "AES_GCM") if (uk) "Рекомендовано." else "Recommended." else if (uk) "НЕ захищає від серйозного злому. Лише для простих нотаток." else "NOT secure against serious attacks. Only for simple notes.", color = if (state.cipherMode == "AES_GCM") MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.error)
                Switch(checked = state.cipherMode == "AES_GCM", onCheckedChange = { vm.setCipherMode(if (it) "AES_GCM" else "CAESAR") })
            }
            item {
                Text(if (uk) "Автоблокування" else "Auto-lock")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf(1, 5, 15).forEach { m -> FilterChipLike("$m хв", state.autoLockMinutes == m) { vm.setAutoLock(m) } } }
            }
            item {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(if (uk) "Біометрія" else "Biometrics")
                        Text(if (uk) "Замінює PIN; головний ключ все одно потрібен." else "Replaces PIN; the master key is still required.")
                    }
                    Switch(checked = state.biometricEnabled, onCheckedChange = { vm.setBiometric(it) }, enabled = (context as? MainActivity)?.biometricAvailable() == true)
                }
            }
            item {
                Text(if (uk) "Мова" else "Language")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChipLike("Українська", state.language == "uk") { vm.setLanguage("uk") }
                    FilterChipLike("English", state.language == "en") { vm.setLanguage("en") }
                }
            }
            item { OutlinedButton(onClick = { showChangePin = true }, modifier = Modifier.fillMaxWidth()) { Text(if (uk) "Змінити PIN" else "Change PIN") } }
            item { OutlinedButton(onClick = { vm.navigate(Screen.EXPORT) }, modifier = Modifier.fillMaxWidth()) { Text(if (uk) "Експорт нотаток" else "Export notes") } }
            item { OutlinedButton(onClick = { vm.navigate(Screen.IMPORT) }, modifier = Modifier.fillMaxWidth()) { Text(if (uk) "Імпорт" else "Import") } }
            item { OutlinedButton(onClick = { vm.navigate(Screen.HELP) }, modifier = Modifier.fillMaxWidth()) { Text(if (uk) "Довідка" else "Help") } }
        }
    }
    if (showChangePin) {
        AlertDialog(onDismissRequest = { showChangePin = false }, title = { Text(if (uk) "Зміна PIN" else "Change PIN") }, text = {
            Column {
                OutlinedTextField(currentPin, { currentPin = it }, label = { Text(if (uk) "Старий PIN" else "Current PIN") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                OutlinedTextField(masterKey, { masterKey = it }, label = { Text(if (uk) "Головний ключ" else "Master key") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                OutlinedTextField(newPin, { if (it.all(Char::isDigit) && it.length <= 6) newPin = it }, label = { Text(if (uk) "Новий PIN" else "New PIN") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
            }
        }, confirmButton = {
            TextButton(onClick = { if (newPin.length in 4..6 && vm.verifyCurrentCredentials(currentPin, masterKey)) { vm.changePin(newPin); showChangePin = false } }) { Text(if (uk) "Зберегти" else "Save") }
        }, dismissButton = { TextButton(onClick = { showChangePin = false }) { Text(if (uk) "Скасувати" else "Cancel") } })
    }
}

@Composable
private fun FilterChipLike(label: String, selected: Boolean, onClick: () -> Unit) {
    if (selected) Button(onClick = onClick, contentPadding = PaddingValues(horizontal = 14.dp, vertical = 4.dp)) { Text(label) }
    else OutlinedButton(onClick = onClick, contentPadding = PaddingValues(horizontal = 14.dp, vertical = 4.dp)) { Text(label) }
}

@Composable
private fun HelpScreen(language: String, onBack: () -> Unit) {
    val uk = language == "uk"
    Scaffold(topBar = { CenterAlignedTopAppBar(title = { Text(if (uk) "Довідка" else "Help") }, navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) } }) }) { padding ->
        LazyColumn(Modifier.fillMaxSize().padding(padding).padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            item { Text(if (uk) "Як працює захист" else "How protection works", style = MaterialTheme.typography.headlineSmall) }
            item { Text(if (uk) "Текст нотаток шифрується AES-256-GCM. Ключ виводиться з PIN і головного ключа через PBKDF2-HMAC-SHA256 з випадковою сіллю та 600 000 ітерацій." else "Note text is encrypted with AES-256-GCM. The key is derived from the PIN and master key using PBKDF2-HMAC-SHA256 with a random salt and 600,000 iterations.") }
            item { Text(if (uk) "У базі даних немає відкритих заголовків, тексту чи тегів. Без правильного ключа показується лише шифротекст." else "The database contains no plaintext titles, bodies or tags. Without the correct key, only ciphertext is shown.") }
            item { Text(if (uk) "Головний ключ не відновлюється. Зміна PIN перебудовує ключ і перешифровує наявні нотатки." else "The master key cannot be recovered. Changing the PIN re-encrypts existing notes under a new derived key.") }
            item { Text(if (uk) "Режим Цезаря слабкий і не призначений для паролів або важливих секретів." else "Caesar mode is weak and is not intended for passwords or important secrets.") }
            item { Text(if (uk) "Застосунок не має INTERNET-дозволу, реклами, аналітики, трекерів чи мережевих викликів." else "The app has no INTERNET permission, ads, analytics, trackers or network calls.") }
        }
    }
}

@Composable
private fun ExportScreen(vm: MainViewModel, state: UiState, onBack: () -> Unit) {
    val uk = state.language == "uk"
    val notes by vm.notes.collectAsState()
    var decrypted by remember { mutableStateOf<Map<String, DecryptedNote>>(emptyMap()) }
    var output by remember { mutableStateOf("") }
    val context = LocalContext.current
    LaunchedEffect(notes) { decrypted = buildMap { notes.forEach { runCatching { vm.decrypt(it) }.getOrNull()?.let { d -> put(d.id, d) } } } }
    Scaffold(topBar = { CenterAlignedTopAppBar(title = { Text(if (uk) "Експорт" else "Export") }, navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) } }) }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            Text(if (uk) "Експорт створює зашифрований Base64-рядок. Його можна перенести без мережі." else "Export creates an encrypted Base64 string that can be transferred without a network.")
            Spacer(Modifier.height(10.dp))
            Button(onClick = { kotlinx.coroutines.MainScope().launch { output = vm.exportAll() ?: "" } }, modifier = Modifier.fillMaxWidth()) { Text(if (uk) "Експортувати всі" else "Export all") }
            Spacer(Modifier.height(10.dp))
            LazyColumn(Modifier.weight(1f)) {
                items(notes, key = { it.id }) { note ->
                    val d = decrypted[note.id]
                    OutlinedButton(onClick = { kotlinx.coroutines.MainScope().launch { output = vm.export(note) ?: "" } }, modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp)) { Text(d?.title ?: "••••••••") }
                }
            }
            if (output.isNotBlank()) {
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(output, {}, readOnly = true, minLines = 5, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = { copyToClipboard(context, output) }, modifier = Modifier.fillMaxWidth()) { Text(if (uk) "Скопіювати зашифрований текст" else "Copy encrypted text") }
                Spacer(Modifier.height(6.dp))
                Text(if (uk) "Скопіюйте цей текст і вставте його в іншому екземплярі застосунку, ввівши той самий головний ключ." else "Copy this text and paste it into another instance of the app using the same master key.")
            }
        }
    }
}

@Composable
private fun ImportScreen(vm: MainViewModel, state: UiState, onBack: () -> Unit) {
    val uk = state.language == "uk"
    var text by rememberSaveable { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    Scaffold(topBar = { CenterAlignedTopAppBar(title = { Text(if (uk) "Імпорт" else "Import") }, navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) } }) }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            Text(if (uk) "Вставте зашифрований Base64-рядок. Потрібен той самий головний ключ." else "Paste the encrypted Base64 string. The same master key is required.")
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(text, { text = it }, minLines = 10, label = { Text(if (uk) "Зашифрований текст" else "Encrypted text") }, modifier = Modifier.fillMaxWidth().weight(1f))
            Spacer(Modifier.height(10.dp))
            Button(onClick = { val result = vm.importText(text); if (result.isSuccess) onBack() else error = if (uk) "Не вдалося імпортувати. Перевірте рядок і головний ключ." else "Import failed. Check the string and master key." }, enabled = text.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text(if (uk) "Імпортувати" else "Import") }
            error?.let { Spacer(Modifier.height(8.dp)); Text(it, color = MaterialTheme.colorScheme.error) }
        }
    }
}

private fun copyToClipboard(context: Context, value: String) {
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    val clip = ClipData.newPlainText("Encrypted Notebook", value)
    clipboard.setPrimaryClip(clip)
    Handler(Looper.getMainLooper()).postDelayed({
        runCatching {
            if (clipboard.primaryClip?.getItemAt(0)?.coerceToText(context)?.toString() == value) {
                clipboard.setPrimaryClip(ClipData.newPlainText("", ""))
            }
        }
    }, 30_000)
}
